load errorvalues.m;
load values.m;

format long;

u = @(x, y) sin(2*pi*x).*sin(2*pi*y) + 1i*x.*(1 - x).*y.*(1 - y);
%X1 = reshape (errorvalues(:, 1), length(errorvalues), 1);
%Y1 = reshape (errorvalues(:, 2), length(errorvalues), 1);

X2 = reshape (values(:, 1), length(values), 1);
Y2 = reshape (values(:, 2), length(values), 1);

M = [linspace(0, 1, length(values))', linspace(0, 1, length(values))'];
ur = real(u(M(:,1),M(:,2)));



 


%reshape (errorvalues(:, 1), length(errorvalues), 1);
%Y1 = reshape (errorvalues(:, 2), length(errorvalues), 1);


Z1 = ur;

Z2 = [X2,Y2];

Z1 = Z1-Z2;

Znorm = norm(Z1)/norm(Z2);
Znorm

%u = @(x, y) sin(2*pi*x).*sin(2*pi*y) + 1i*x.*(1 - x).*y.*(1 - y)
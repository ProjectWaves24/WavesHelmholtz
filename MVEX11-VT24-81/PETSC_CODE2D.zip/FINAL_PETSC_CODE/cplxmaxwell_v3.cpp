// to compile:
// runmaxwellv3 argv[1] argv[2] argv[3] argv[4]
// Arguments:
// argv[1] - number of discretization points in x and y directions
// argv[2] - frequency omegareal
// argv[3] - preconditioner (should be 1,2,3 or 4)
// argv[4] - damping coefficient alpha
#include<iostream>
#include<fstream>
#include<petsc.h>
#include<petscvec.h>
#include<petscmat.h>
#include<petscksp.h>
#include<complex>

using namespace std;

static char help[] ="";


PetscScalar   epsilon(const PetscReal x, const PetscReal y)
{
  PetscReal rpart, ipart;
  
PetscReal x_0=0.5;
PetscReal y_0=0.5;
PetscReal c_x=1;
PetscReal c_y=1;

 rpart = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));

  ipart = 0;    

  PetscScalar scalareps(rpart, ipart);
  return scalareps;
  
}

PetscScalar   epsilon_test2(const PetscReal x, const PetscReal y)
{
  PetscReal rpart, ipart;
  


  rpart = 1.0 + 2*exp(-((x-0.5)*(x-0.5)/0.001 +(y-0.7)*(y-0.7)/0.001)) + 3*exp(-((x-0.2)*(x-0.2)/0.001 +(y-0.6)*(y-0.6)/0.001));

  ipart = 0;    

  PetscScalar scalareps(rpart, ipart);
  return scalareps;
  
}


PetscScalar right_hand_side_test2(const PetscReal x, const PetscReal y,
			    const PetscReal omega)
{
  PetscReal rpart, ipart, pi = 3.14159265359;

  
  PetscReal epsilon_real = 1.0 + 2*exp(-((x-0.5)*(x-0.5)/0.001 +(y-0.7)*(y-0.7)/0.001)) + 3*exp(-((x-0.2)*(x-0.2)/0.001 +(y-0.6)*(y-0.6)/0.001));

 
  rpart =  -(8*pi*pi)*sin(2*pi*x)*sin(2*pi*y)+ omega*omega*epsilon_real*(sin(2*pi*x)*sin(2*pi*y));
  
  ipart = -2*(x - x*x + y - y*y) + omega*omega*epsilon_real*x*(1-x)*y*(1-y);
    
  PetscScalar f(rpart, ipart);
  return f;
}


PetscScalar right_hand_side(const PetscReal x, const PetscReal y,
			    const PetscReal omega)
{
  PetscReal rpart, ipart, pi = 3.14159265359;


  PetscReal x_0=0.5;
  PetscReal y_0=0.5;
  PetscReal c_x=1;
  PetscReal c_y=1;
  PetscReal epsilon_real = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));
 
 
  rpart =  -(8*pi*pi)*sin(2*pi*x)*sin(2*pi*y)+ omega*omega*epsilon_real*(sin(2*pi*x)*sin(2*pi*y));
  
  ipart = -2*(x - x*x + y - y*y) + omega*omega*epsilon_real*x*(1-x)*y*(1-y);
    
  PetscScalar f(rpart, ipart);
  return f;
}



PetscScalar wave_number(const PetscReal kreal, const PetscReal kimag)
{
  //PetscReal rpart, ipart;
    //rpart = 1;
    //ipart = 1;
    PetscScalar k(kreal, kimag);
    return k;
}

int main(int argc, char **argv)
{
  cout << "Initializing ..." << endl;
  // PetscInitialize(&argc, &argv, NULL, NULL);
PetscInitialize(&argc, &argv,(char *)0, help);

 
 int rank;
 MPI_Comm_rank(MPI_COMM_WORLD, &rank);
     
  cout << "Setting parameters..." << endl;
  PetscErrorCode ierr;
  Vec b, u;
  Mat A;
  KSP ksp;
  PetscInt Nx = atoi(argv[1]), Ny = Nx, Nsys, node_idx = 0, col[5], nadj;
  Nsys = Nx*Ny; // dimension  of linear system = number of nodes
  PetscReal x[Nx], y[Ny], nodes[Nsys][2];
  PetscScalar value, diffpoints[5], h;
  
  // Set up vectors
  cout << "Setting up vectors..." << endl;
  ierr = VecCreate(PETSC_COMM_WORLD, &b); CHKERRQ(ierr);
  ierr = VecSetSizes(b, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
  ierr = VecSetType(b, VECSTANDARD); CHKERRQ(ierr);
  ierr = VecDuplicate(b, &u);
  
  // Set up matrix
  cout << "Setting up matrix..." << endl;
  ierr = MatCreate(PETSC_COMM_WORLD, &A); CHKERRQ(ierr);
  ierr = MatSetSizes(A,PETSC_DECIDE, PETSC_DECIDE, Nsys, Nsys); CHKERRQ(ierr);
  ierr = MatSetFromOptions(A); CHKERRQ(ierr);
  ierr = MatSetUp(A); CHKERRQ(ierr);

  // Create grid
  cout << "Constructing grid..." << endl;
  h = 1.0/(Nx - 1);
  for (int i = 0; i < Nx; i++)
    x[i] = 1.0*i/(Nx - 1);
  for (int j = 0; j < Ny; j++)
    y[j] = 1.0*j/(Ny - 1);
  
  // Assemble linear system ...
  cout << "Assembling system..." << endl;

  PetscScalar k;
  //double omegareal=40;
  
  double omegareal  =  atof(argv[2]);

 cout << "Checking input parameters..." << endl;
 cout<<" Arguments: "<<argc<<endl;
 
 //double pi = 3.141592653589793;
 

 PetscScalar  resonance_frequency = 0.0;
 PetscScalar  input_frequency = omegareal;
   
   double b1 = 1.0; // size of the rectangular domain in x direction
   double b2 = 1.0;  // size of the rectangular domain in y direction


   double norm_input_freq;
   double norm_resonance_freq;
   double tolerance = 0.1;
  
   
 double real_part_input_freq;
 double imag_part_input_freq;
 double real_part_resonance_freq;
 double imag_part_resonance_freq;


 // compute wave length for epsilon = 1

 
 double wave_length = (2*M_PI)/omegareal;

 //compute number of points per wave length

 double M = wave_length/real(h);

 // accordingly to theory we should have: h omega = (2 pi)/(max(epsilon) M) < (2 pi)/ M,
 // and error in the solution to Helmholtz eq.
 // is bounded by Const. h^2 omega^3 - thus, we want to have h omega < < 1,
 // or  we check condition  (2 pi)/M < 1.
 // here max(epsilon) = 2 and thus,  we divide by  sqrt(2) - see Lecture of Ol.Runborg
 // We have following estimate for a priori error:
 double apriori_error  = (2*M_PI)/(sqrt(2)*M);
 
  
  cout<<"Number of points per wave length: "<<M<<"wave length= "<<wave_length<<" mesh size h = "<<h<<"   A priori error = "<<apriori_error<<endl;
double alpha=atoi(argv[4]);;
  
 if(argc>2) {
  
  for (int i = 0; i < Nx; i++)
    {
      for (int j = 0; j < Ny; j++)
	{
	    
	  nodes[node_idx][0] = x[i];
	  nodes[node_idx][1] = y[j];

	  resonance_frequency = M_PI*sqrt(((i*i)/(b1*b1) + (j*j)/(b2*b2))/epsilon(x[i], y[j]));
	 
           real_part_resonance_freq  = real(resonance_frequency);
	   imag_part_resonance_freq  = imag(resonance_frequency);

	   real_part_input_freq  = real(input_frequency);
	   imag_part_input_freq  = imag(input_frequency);
	   
	    norm_input_freq = sqrt( real_part_input_freq*real_part_input_freq +
				    imag_part_input_freq*imag_part_input_freq);	     
	  norm_resonance_freq = sqrt(real_part_resonance_freq*real_part_resonance_freq + imag_part_resonance_freq*imag_part_resonance_freq);

	   if ( fabs(norm_input_freq - norm_resonance_freq)  < 1.0 )
  cout<<"  norm_input_freq = "<<norm_input_freq<<"norm_resonance_freq = "<< norm_resonance_freq<<" fabs(norm_input_freq - norm_resonance_freq) = "<<fabs(norm_input_freq - norm_resonance_freq)<<endl;
	

  if (i > 0 && i < Nx - 1 && j > 0 && j < Ny - 1) // for interior  nodes
    {
	  if ( fabs(norm_input_freq - norm_resonance_freq)  < tolerance ||  apriori_error >= 1.0 )
	     {
	       cout<<"*********************************************************************************"<<endl;

	       if ( fabs(norm_input_freq - norm_resonance_freq)  < 1.0 )
  cout<<"  norm_input_freq = "<<norm_input_freq<<"norm_resonance_freq = "<< norm_resonance_freq<<" fabs(norm_input_freq - norm_resonance_freq) = "<<fabs(norm_input_freq - norm_resonance_freq)<<endl;

	       cout<<" A priori error = "<<apriori_error<<"  for x = "<<x[i]<<"  and y = "<<y[j]<<endl;
  cout<< "Warning: this is  resonant frequency or a priori error is  >= 1. Choose another frequency !!!"<<endl;
 cout<<"*********************************************************************************"<<endl;
   
  // exit(1);
	     }
    }
	 
	     
	   k = omegareal*omegareal*epsilon(x[i], y[j]);
	  //k = omegareal*omegareal*epsilon_test2(x[i], y[j]);
	 
	  diffpoints[0] =  -4.0 + h*h*k+PETSC_i*h*h*(alpha/10000)*omegareal;
        diffpoints[1] = 1.0;
        diffpoints[2] = 1.0;
        diffpoints[3] = 1.0;
        diffpoints[4] = 1.0;

	  if (i > 0 && i < Nx - 1 && j > 0 && j < Ny - 1) // interior
	    {
            col[0] = node_idx;
            col[1] = node_idx - 1;
            col[2] = node_idx + 1;
            col[3] = node_idx - Ny;
            col[4] = node_idx + Ny;
            
            nadj = 5;
            value = h*h*right_hand_side(x[i], y[j],omegareal);
	    //   value = h*h*right_hand_side_test2(x[i], y[j],omegareal);
	    } else // on boundary
	    {
	      col[0] = node_idx;
	      nadj   = 1;
	      value  = 0.0;
	    }
	  
	  ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); CHKERRQ(ierr);
	  ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);
	  node_idx++;
	}
    }
  ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

  // * ********************************************************************* * //
  // * ********************************************************************* * //
  // * ********************************************************************* * //
  // Residual history
  PetscReal* hist;
  PetscInt  nHist;
  PetscInt  maxIt;

  // Set History
  PetscMalloc(maxIt * sizeof(PetscReal), &hist);
  hist = NULL;
  nHist = 0;
  maxIt = 1000;
  // * ********************************************************************* * //
  // * ********************************************************************* * //
  // * ********************************************************************* * //

  // Solve linear system
  cout << "Solving linear system ..." << endl;
  ierr = KSPCreate(PETSC_COMM_WORLD, &ksp); CHKERRQ(ierr);
  ierr = KSPSetOperators(ksp, A, A); CHKERRQ(ierr);
  // Preconditioners
  PC pc;
  ierr = KSPGetPC(ksp, &pc); CHKERRQ(ierr); 
  //ierr = PCSetType(pc, PCSOR); CHKERRQ(ierr);
  ///First draft
  
  PetscInt method =  atoi(argv[3]);
  //PC pc;
  
  if (method < 1 || method > 4) {
        cout << "Invalid number of the selected method: "
	     << method << ".\nExiting..." << endl;
        exit(-1);
    }
    if (method == 1)
      {
 ierr =	PCSetType(pc,PCJACOBI); CHKERRQ(ierr);
      }
    else if (method == 2)
      {
	// Gauss-Seidel preconditioner : the same as SOR when omega=1
 ierr = PCSetType(pc, PCSOR); 	
  CHKERRQ(ierr);
      }
else if (method == 3)
  {
    const PetscReal omega = 1.5;
    ierr = PCSetType(pc, PCSOR); CHKERRQ(ierr);
    ierr = PCSORSetOmega(pc, omega); CHKERRQ(ierr);
  }
  else if (method == 4)
  {
  ierr = KSPGetPC(ksp, &pc); CHKERRQ(ierr);
  }
  
  
  
  
  
  
  
  
  
  
  
  //ierr = PCSORSetOmega(pc, 1);
  
  
  ierr = KSPSetTolerances(ksp, PETSC_DEFAULT, PETSC_DEFAULT, PETSC_DEFAULT, maxIt); CHKERRQ(ierr);
  ierr = KSPSetFromOptions(ksp); CHKERRQ(ierr);
  // * ********************************************************************* * //
  // * ********************************************************************* * //
  // * ********************************************************************* * //
  ierr = KSPSetResidualHistory(ksp, hist, maxIt, PETSC_TRUE); CHKERRQ(ierr);
  ierr = KSPSolve(ksp, b, u); CHKERRQ(ierr);
  ierr = KSPGetResidualHistory(ksp, &hist, &nHist); CHKERRQ(ierr);

   FILE* residfile = fopen("residual.m", "w");
   fprintf(residfile, "nHist: %d\n", nHist);

  for (PetscInt it = 0; it < nHist; it++)
    fprintf(residfile, "%d-ksp-iteration: %f\n", it, hist[it]);
  
  // * ********************************************************************* * //
  // * ********************************************************************* * //
  // * ********************************************************************* * //

  // Print to files
  cout << "Writing to files..." << endl;
  FILE* nodefile = fopen("nodes.m", "w");
  for (int idx = 0; idx < Nsys; idx++)
    fprintf(nodefile, "%f \t %f \n", nodes[idx][0], nodes[idx][1]);
  fclose(nodefile);
  FILE* solfile = fopen("values.m", "w");
  for (int idx = 0; idx < Nsys; idx++)
    {
      ierr = VecGetValues(u, 1, &idx, &value);
      fprintf(solfile, "%f \t %f \n", real(value), imag(value));
    }
  fclose(solfile);

  // Clean up
  ierr = VecDestroy(&b); CHKERRQ(ierr);
  ierr = VecDestroy(&u); CHKERRQ(ierr);
  ierr = MatDestroy(&A); CHKERRQ(ierr);
  ierr = KSPDestroy(&ksp); CHKERRQ(ierr);

 }
  else {cout<< "Usage: see CONFIGURATION: argv[1] argv[2] are not defined ! "<<endl;}
  
  // Finalize and finish
  ierr = PetscFinalize();
  return 0;
}


system("cd Desktop/CONVERGENCEMaxwell2D/");
system("make -f makefile_v3 runmaxwellv3");
n=input("Antal noder ");
w=input("Frekvens ");
meth=input("Metod, 1 är Jacobi, 2 är Gauss-Seidel, 3 är SOR, 4 är KSP ");
alpha=input("Damping coeff. ");
command = sprintf("./runmaxwellv3 %d %d %d %d", n,w,meth,alpha);
system(command); 
load nodes.m
load values.m
u = @(x, y) sin(2*pi*x).*sin(2*pi*y) + 1i*x.*(1 - x).*y.*(1 - y);

x_0=0.5;
y_0=0.5;
c_x= 0.1;
c_y=0.1;

 epsilon = @(x, y) 2*exp(-((x-x_0).*(x-x_0)/(2*c_x.*c_x) +(y-y_0).*(y-y_0)/(2*c_y.*c_y)));

% for test 2
%epsilon = @(x, y) 1 +  2*exp(-((x-0.5).*(x-0.5) +(y-0.7).*(y-0.7))/0.001) +  3*exp(-((x-0.2).*(x-0.2) +(y-0.6).*(y-0.6))/0.001);


n = sqrt(size(nodes, 1));
X = reshape(nodes(:, 1), n, n);
Y = reshape(nodes(:, 2), n, n);
Ur = reshape(values(:, 1), n, n);
Ui = reshape(values(:, 2), n, n);



[Xe, Ye] = meshgrid(linspace(0, 1, 30), linspace(0, 1, 30));
ur = real(u(Xe, Ye));
ui = imag(u(Xe, Ye));

Eps = epsilon(Xe, Ye)


subplot(3, 2, 1)
surf(X', Y', Ur)
title('u_h Real, computed')
%  view(2)
  
subplot(3, 2, 2)
surf(Xe, Ye, ur)
title('u Real, exact')
%  view(2)
  
subplot(3, 2, 3)
surf(X', Y', Ui)
title('u_h Imag, computed')
%  view(2)
  
subplot(3, 2, 4)
surf(Xe, Ye, ui)
title('u Imag, exact')
%  view(2)
  
subplot(3, 2, 5)
surf(Xe, Ye, Eps)
  title('exact  epsilon, 3D view')

subplot(3, 2, 6)
surf(Xe, Ye, Eps)
view(2)
title('exact  epsilon, 2D')
shg




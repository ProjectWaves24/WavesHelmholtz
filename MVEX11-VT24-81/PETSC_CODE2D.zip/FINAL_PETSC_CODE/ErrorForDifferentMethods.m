system("cd Desktop/CONVERGENCEMaxwell2D/");%Skriver kommandon i terminalen
%Du behöver byta "path" till CONVERGENCEMaxwell2D, annars kommer det inte att fungera.
system("make -f makefileconv_v2 runconv2");%Låt stå
system("make runmaxwell");%Låt stå
KoraKod= input("Vill du köra koden, 1 för ja, 0 för nej: ");
if KoraKod>0
    frequency = 300;%15:1:30;%lista över frekvenser som kommer köras
    nodes = 13:25:513;%lista över noder

    %(chalmersdatorer klarar bara till 722 noder, 722 noder tar väldigt lång tid)
    amount = length(frequency)*length(nodes)*4; %Räknar totala for loopens iterationer
    MoM = cell(1,length(frequency)) ; % Skapar Matrix of matrices för errors
    m=1; %  räknar vilken iteration loopen är på
    wb = waitbar(0, "Running"); % Får en wairbar så man får ett humm om hur lång tid programmet kommer ta
    for i = 1:length(frequency)
        
        NMat=[]; %Skapar matris
        for methods = [1,2,3,4] % Alla implementerade matoder (relativt lätt att läggat till fler)
            
            Nvec = []; %skapar columner
            for v = nodes
                waitbar(m/amount,wb,sprintf("Running for w= %d, md= %d and n= %d", frequency(i),methods,v));%
                % lägger till vad programmet kör för
                m=m+1;
               
            
            
                w=frequency(i);
                
                alpha = 50000; %damping coefficient för dampning term
                if methods == 4 %kör ett specifikt programm för ksp
                    command = sprintf("./runmaxwell %d %d %d", v, w, alpha);
                end
                if methods < 4 %kör annat för gauss, jacobi och SOR
                    command = sprintf('./runconv2 %d %d %d %f', v, w, methods, alpha);
                end
                system(command);
                
                load errorvalues.m; % laddar in errorvalues samt values som uppdateras efter PETSc körs
                load values.m; % 
                
                format long;
                
                x1 = reshape (errorvalues(:, 1), length(errorvalues), 1);
                x2 = reshape (values(:, 1), length(values), 1);

                y1 = reshape (errorvalues(:, 2), length(errorvalues), 1);
                y2 = reshape (values(:, 2), length(values), 1);
                %övre kod fixar om datan till matlabs standardformat
                
                z1 = [x1,y1];
                z2 = [x2,y2];
                
                znorm = norm(z1)/norm(z2); %Relativt fel
                if znorm == inf
                    Nvec = [Nvec;10^8]; %Fixar en övre begränsing till det relativa felet 
                
                else
                    Nvec= [Nvec;znorm];
                end
                
            end
            
            NMat = [NMat,Nvec];
            
            
        end
        MoM{i}=NMat;
        
    
    end
end


    


if 1>0
    KoraGif=0;
    KoraFleraPlot = input("Vill du få alla plots, 1 för ja 0 för nej: ");
    if KoraFleraPlot <=0
        KoraGif=input("Vill du istället få Gifen, 1 för ja, 0 för nej: ");
    end


    
    for freq = frequency %kan bli väldigt många plots, ändra gärna listan för att få den plot som önskas
        %kan lägga till [ find(frequency==input("vilken frekvens söks?")) ] för
        %att få önskad frekvens
        freqindex = find(frequency==freq);
        if KoraFleraPlot >0 
            figure; hold on; % Skapar en figur för varje plot
            set(gca, 'YScale', 'log'); % Y axeln blir log-skala
            xticks(nodes); %Antal noder på plottens x-axel
        end
        for j = 1:size(MoM{freqindex}, 2)

            if KoraFleraPlot>0 %koden nedanför plottar
                if j ==1
                    h=plot(nodes, MoM{freqindex}(:, j), '-.', 'DisplayName', 'Jacobi');
    
                    color = get(h, 'Color');
                    color(1)=1;
                    color(2)=0;
                    color(3)=0;
                    
                    color(4) = 1;
                    set(h, 'Color', color);
                    set(h,{'LineWidth'},{2});

                end
                if j ==2
                    h=plot([0,nodes], [MoM{freqindex}(1, j);MoM{freqindex}(:, j)], '-', 'DisplayName', 'Gauss-Seidel');
                    color = get(h, 'Color');
                    color(1)=0;
                    color(2)=1;
                    color(3)=0;
                    color(4) = 0.6;
                    set(h, 'Color', color);
                    set(h,{'LineWidth'},{2});
                end
                  
                if j ==3
                    h=plot([0,nodes], [MoM{freqindex}(1, j);MoM{freqindex}(:, j)], ':', 'DisplayName', 'SOR');
                    color = get(h, 'Color');
                    color(1)=0;
                    color(2)=0;
                    color(3)=1;
                    color(4) = 0.4;
                    set(h, 'Color', color);
                    set(h,{'LineWidth'},{2});
                end

                if j ==4
                    h=plot([0,nodes], [MoM{freqindex}(1, j);MoM{freqindex}(:, j)], '--', 'DisplayName', 'KSP');
                    color = get(h, 'Color');
                    color(1)=0;
                    color(2)=0;
                    color(3)=0;
                    color(4) = 0.2;
                    set(h, 'Color', color);
                    set(h,{'LineWidth'},{2});
                end

            end

            
            if KoraGif>0 %koden nedanför fixar animationen

                while 1>0 %oändlig loop, kan ändra så att man kör ett fixt antal gånger,
                    %ändra till for i = 0:1:[antal gånger]
                    for w = frequency % kör animationen framåt
                        updatePlot(w, frequency, MoM, nodes); %en funktion som uppdaterar en figur för bestämda värden
                        pause(0.05); %Pausar för att få en fin uppdateringsfrekvens
                        
                    end
                    pause(1); % Paus innan den ändrar riktning

                    for w = frequency(length(frequency)):frequency(1)-frequency(2):frequency(1) % lista med frekvenser, fast baklänges
                        updatePlot(w, frequency, MoM, nodes); % --||--
                        pause(0.05);%--||--
                        
                    end
                    
                end
            end
        end 
        
        if  KoraFleraPlot >0 % denna är nedanför för att få plotten med alla metoder samt olika figurer och med legends
            xlabel('Antal diskretiseringpunkter i x och y led');
            ylabel('Relativt fel');
            title(sprintf('Relativa felen för \x03c9 =%d', frequency(freqindex)));
            legend('Location', 'northeast');
            grid off;
            hold off;
        end
        
    end
end

function updatePlot(w, frequency, MoM, nodes)
    clf;
    hold on;
    set(gca, 'YScale', 'log') %--||--
    xlabel('Antal diskretiseringpunkter i x och y led');%--||--
    xticks(nodes);%--||--
    ylabel('Relativt fel');
    title(sprintf('Relativa felen för \x03c9 =%d', w));
    ylim([10^(-7), 10^8]);%Sätter övre och nedre begränsinng på plotten
    legend('location','northeast');
    grid off;%Vill ej ha rutnät på plotten
    
    
    for j = 1:4 % Plottar varje metod, ifall fler metoder läggs till, ändra 4:an till antal metoder 
        % Hittar indexeringen för frekvensen vi kollar på
        freq_index = find(frequency == w);
        
        % Får data för aktuell frekvens från matrisen
        data = MoM{freq_index}(:, j);
        
        
        % Plottar datan
        if j ==1
                    
            h=plot(nodes, data, '-.', 'DisplayName', 'Jacobi');
    
                   
            color = get(h, 'Color');
                    
            color(1)=1;
                    
            color(2)=0;
                    
            color(3)=0;
                    
                    
            color(4) = 1;
                    
            set(h, 'Color', color);
                    
            set(h,{'LineWidth'},{4});
            
        end
        
        if j ==2
        
            h=plot(nodes, data, '-', 'DisplayName', 'Gauss-Seidel');
            
            color = get(h, 'Color');
            
            color(1)=0;
            
            color(2)=1;
            
            color(3)=0;
            
            color(4) = 0.6;
            
            set(h, 'Color', color);
            
            set(h,{'LineWidth'},{4});
            
        end
        

        
        if j ==3
        
            h=plot(nodes, data, ':', 'DisplayName', 'SOR');
            
            color = get(h, 'Color');
            
            color(1)=0;
            
            color(2)=0;
            
            color(3)=1;
            
            color(4) = 0.4;
            
            set(h, 'Color', color);
            
            set(h,{'LineWidth'},{4});
            
        end
        if j ==4
                    
            h=plot(nodes, data, '--', 'DisplayName', 'KSP');
                    
            color = get(h, 'Color');
                    
            color(1)=0;
                    
            color(2)=0;
                    
            color(3)=0;
                    
            color(4) = 0.2;
                    
            set(h, 'Color', color);
                    
            set(h,{'LineWidth'},{4});
        end

    end

end


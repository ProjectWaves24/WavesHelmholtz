load errorvalues.m;
load values.m;

format long;

X1 = reshape (errorvalues(:, 1), length(errorvalues), 1);
Y1 = reshape (errorvalues(:, 2), length(errorvalues), 1);

X2 = reshape (values(:, 1), length(values), 1);
Y2 = reshape (values(:, 2), length(values), 1);


Z1 = [X1,Y1];
Z2 = [X2,Y2];

Znorm = norm(Z1)/norm(Z2);

Znorm

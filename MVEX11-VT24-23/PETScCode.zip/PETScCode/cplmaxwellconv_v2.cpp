#include<fstream>
#include "cplmaxwellconv_v2_Neumann2.h"
#include "cplmaxwellconv_v2_Dirichlet.h"
#include "cplmaxwellconv_v2_Neumann1.h"
#include<stdlib.h>
#include<math.h>

//-------------Funktioner------------------
double r(double e1, double e0){
  return abs(log(e1/e0))/abs(log(0.5));
}

void print_first_line(std::ofstream &table)
{
 table << "Förkonditioneringsmedel, e_l, r_l, C_l \n";
}

void writerow(std::ofstream &table, double h, double *error_and_omega, 
	double prev, int precond, int nr_nodes)
{
  double r_l;
  double C;
  if (precond == 1){
    table << "Jacobi,";
  }else if (precond == 2){
    table << "Gauss-Seidel,";
  }else if (precond == 3){
    table << "SOR,";
  }else if (precond == 4){
    table << "Block Jacobi,";
  }else if (precond == 5){
    table << "SOR med Eisenstats trick,";
  }else if (precond == 6){
    table << "Ofullständig Cholesky,";
  }else if (precond == 7){
    table << "Ofullständig LU,";
  }else if (precond == 8){
    table << "Additiv Schwartz,";
  }else if (precond == 9){
    table << "Generaliserad additiv Schwartz,";
  }else if (precond == 10){
    table << "Algebraic multigrid,";
  }else if (precond == 11){
    table << "Linjär lösare,";
  }else if (precond == 12){
    table << "LU,";
  }else if (precond == 13){
    table << "Cholesky,";
  }
  if (nr_nodes == 9){
    table << error_and_omega[0] << ",-,-" << "\n";
  }else{
    r_l = r(error_and_omega[0], prev);
    C = error_and_omega[0]/pow(h,2);
    table << error_and_omega[0] << "," << r_l << "," << C << "\n";
  }
  return;
}

int createtables(std::ofstream &table_d, std::ofstream &table_n1, 
	std::ofstream &table_n2, int nr_nodes, double *d, double *n1, 
	double *n2, int last_time, double *d_prev, double *n1_prev, 
	double *n2_prev)
{
  double h = (double) 1. / ((double) nr_nodes - 1.);

  cout << "creating row 1..." << endl;
  dirichlet(1, nr_nodes, d);
  neumann1(1, nr_nodes, n1);
  neumann2(1, nr_nodes, n2, last_time);

  writerow(table_d, h, d, d_prev[0], 1, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[0], 1, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[0], 1, nr_nodes);
  
  d_prev[0] = d[0];
  n1_prev[0] = n1[0];
  n2_prev[0] = n2[0];
  
  cout << "creating row 2..." << endl;
  dirichlet(2, nr_nodes, d);
  neumann1(2, nr_nodes, n1);
  neumann2(2, nr_nodes, n2, last_time);

  writerow(table_d, h, d, d_prev[1], 2, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[1], 2, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[1], 2, nr_nodes);

  d_prev[1] = d[0];
  n1_prev[1] = n1[0];
  n2_prev[1] = n2[0];
  
  cout << "creating row 3..." << endl;
  dirichlet(3, nr_nodes, d);
  neumann1(3, nr_nodes, n1);
  neumann2(3, nr_nodes, n2, last_time);

  writerow(table_d, h, d, d_prev[2], 3, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[2], 3, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[2], 3, nr_nodes);
  
  d_prev[2] = d[0];
  n1_prev[2] = n1[0];
  n2_prev[2] = n2[0];
  
  cout << "creating row 4..." << endl;
  dirichlet(4, nr_nodes, d);
  neumann1(4, nr_nodes, n1);
  neumann2(4, nr_nodes, n2, last_time);

  writerow(table_d, h, d, d_prev[3], 4, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[3], 4, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[3], 4, nr_nodes);
  
  d_prev[3] = d[0];
  n1_prev[3] = n1[0];
  n2_prev[3] = n2[0];
  
  cout << "creating row 5..." << endl;
  dirichlet(5, nr_nodes, d);
  neumann1(5, nr_nodes, n1);
  neumann2(5, nr_nodes, n2, last_time);

  writerow(table_d, h, d, d_prev[4], 5, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[4], 5, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[4], 5, nr_nodes);
  
  d_prev[4] = d[0];
  n1_prev[4] = n1[0];
  n2_prev[4] = n2[0];
  
  cout << "creating row 6..." << endl;
  dirichlet(6, nr_nodes, d);
  neumann1(6, nr_nodes, n1);
  neumann2(6, nr_nodes, n2, last_time);

  writerow(table_d, h, d, d_prev[5], 6, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[5], 6, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[5], 6, nr_nodes);
  
  d_prev[5] = d[0];
  n1_prev[5] = n1[0];
  n2_prev[5] = n2[0];
  
  cout << "creating row 7..." << endl;
  dirichlet(7, nr_nodes, d);
  neumann1(7, nr_nodes, n1);
  neumann2(7, nr_nodes, n2, last_time);
  
  writerow(table_d, h, d, d_prev[6], 7, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[6], 7, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[6], 7, nr_nodes);
  
  d_prev[6] = d[0];
  n1_prev[6] = n1[0];
  n2_prev[6] = n2[0];
  
  cout << "creating row 8..." << endl;
  dirichlet(8, nr_nodes, d);
  neumann1(8, nr_nodes, n1);
  neumann2(8, nr_nodes, n2, last_time);
  
  writerow(table_d, h, d, d_prev[7], 8, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[7], 8, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[7], 8, nr_nodes);
  
  d_prev[7] = d[0];
  n1_prev[7] = n1[0];
  n2_prev[7] = n2[0];
  
  cout << "creating row 9..." << endl;
  dirichlet(9, nr_nodes, d);
  neumann1(9, nr_nodes, n1);
  neumann2(9, nr_nodes, n2, last_time);
  
  writerow(table_d, h, d, d_prev[8], 9, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[8], 9, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[8], 9, nr_nodes);
  
  d_prev[8] = d[0];
  n1_prev[8] = n1[0];
  n2_prev[8] = n2[0];
  
  cout << "creating row 10..." << endl;
  dirichlet(10, nr_nodes, d);
  neumann1(10, nr_nodes, n1);
  neumann2(10, nr_nodes, n2, last_time);
  
  writerow(table_d, h, d, d_prev[9], 10, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[9], 10, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[9], 10, nr_nodes);
  
  d_prev[9] = d[0];
  n1_prev[9] = n1[0];
  n2_prev[9] = n2[0];
  cout << "creating row 11..." << endl;
  
  dirichlet(11, nr_nodes, d);
  neumann1(11, nr_nodes, n1);
  neumann2(11, nr_nodes, n2, last_time);
  
  writerow(table_d, h, d, d_prev[10], 11, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[10], 11, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[10], 11, nr_nodes);
  
  d_prev[10] = d[0];
  n1_prev[10] = n1[0];
  n2_prev[10] = n2[0];
  
  cout << "creating row 12..." << endl;
  dirichlet(12, nr_nodes, d);
  neumann1(12, nr_nodes, n1);
  neumann2(12, nr_nodes, n2, last_time);
  
  writerow(table_d, h, d, d_prev[11], 12, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[11], 12, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[11], 12, nr_nodes);
  
  d_prev[11] = d[0];
  n1_prev[11] = n1[0];
  n2_prev[11] = n2[0];
  
  cout << "creating row 13..." << endl;
  dirichlet(13, nr_nodes, d);
  neumann1(13, nr_nodes, n1);
  neumann2(13, nr_nodes, n2, last_time);
  
  writerow(table_d, h, d, d_prev[12], 13, nr_nodes);
  writerow(table_n1, h, n1, n1_prev[12], 13, nr_nodes);
  writerow(table_n2, h, n2, n2_prev[12], 13, nr_nodes);
  
  d_prev[12] = d[0];
  n1_prev[12] = n1[0];
  n2_prev[12] = n2[0];
  
  return 0;
}

//-------------Main------------------------
int main()
{
  double d[2];
  double n1[2];
  double n2[2];
  double d_prev[13] = {};
  double n1_prev[13] = {};
  double n2_prev[13] = {};

  std::ofstream table1_d("table1_d.csv");
  std::ofstream table1_n1("table1_n1.csv");
  std::ofstream table1_n2("table1_n2.csv");
  print_first_line(table1_d);
  print_first_line(table1_n1);
  print_first_line(table1_n2);
  createtables(table1_d, table1_n1, table1_n2, 9, d, n1, n2, 0, 
	d_prev, n1_prev, n2_prev);
  table1_d.close();
  table1_n1.close();
  table1_n2.close();
  
  std::ofstream table2_d("table2_d.csv");
  std::ofstream table2_n1("table2_n1.csv");
  std::ofstream table2_n2("table2_n2.csv");
  print_first_line(table2_d);
  print_first_line(table2_n1);
  print_first_line(table2_n2);
  createtables(table2_d, table2_n1, table2_n2, 17, d, n1, n2, 0, 
	d_prev, n1_prev, n2_prev);
  table2_d.close();
  table2_n1.close();
  table2_n2.close();
  
  std::ofstream table3_d("table3_d.csv");
  std::ofstream table3_n1("table3_n1.csv");
  std::ofstream table3_n2("table3_n2.csv");
  print_first_line(table3_d);
  print_first_line(table3_n1);
  print_first_line(table3_n2);
  createtables(table3_d, table3_n1, table3_n2, 33, d, n1, n2, 0, 
	d_prev, n1_prev, n2_prev);
  table3_d.close();
  table3_n1.close();
  table3_n2.close();
  
  std::ofstream table4_d("table4_d.csv");
  std::ofstream table4_n1("table4_n1.csv");
  std::ofstream table4_n2("table4_n2.csv");
  print_first_line(table4_d);
  print_first_line(table4_n1);
  print_first_line(table4_n2);
  createtables(table4_d, table4_n1, table4_n2, 65, d, n1, n2, 0, 
	d_prev, n1_prev, n2_prev);
  table4_d.close();
  table4_n1.close();
  table4_n2.close();
  
  std::ofstream table5_d("table5_d.csv");
  std::ofstream table5_n1("table5_n1.csv");
  std::ofstream table5_n2("table5_n2.csv");
  print_first_line(table5_d);
  print_first_line(table5_n1);
  print_first_line(table5_n2);
  createtables(table5_d, table5_n1, table5_n2, 129, d, n1, n2, 1, 
	d_prev, n1_prev, n2_prev);
  table5_d.close();
  table5_n1.close();
  table5_n2.close();
}

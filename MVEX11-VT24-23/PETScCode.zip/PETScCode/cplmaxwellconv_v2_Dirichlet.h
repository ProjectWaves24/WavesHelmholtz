int exactCalcD(Vec exact_vector, PetscScalar value_exact, PetscErrorCode ierr, 
	PetscInt node_idx, PetscInt Nx, PetscInt Ny, PetscReal x[], PetscReal y[])
{
  node_idx = 0;
  for (int i = 0; i < Nx; i++)
  {
    for (int j = 0; j < Ny; j++)
    {
      value_exact = exact_solution(x[i], y[j]);
      ierr = VecSetValues(exact_vector, 1, &node_idx, &value_exact, 
      		INSERT_VALUES); CHKERRQ(ierr);
      node_idx++;
    }
  }
  return 0;
}

double calculationsD(int method, double omegareal, int i, Vec b, Vec u, 
	Vec exact_vector, Mat A, KSP ksp, PC preconditioner, PetscInt Nx, 
	PetscInt Ny, PetscInt Nsys, PetscInt node_idx, PetscInt col[], 
	PetscInt nadj, PetscReal x[], PetscReal y[], PetscReal nodes[][2], 
	PetscScalar value, PetscScalar value_epsilon, PetscScalar value_exact, 
	PetscScalar diffpoints[], PetscScalar h, PetscErrorCode ierr, 
	PetscScalar k)
{
  node_idx = 0;

  for (int i = 0; i < Nx; i++)
  {
    for (int j = 0; j < Ny; j++)
    {
      nodes[node_idx][0] = x[i];
      nodes[node_idx][1] = y[j];

      k = omegareal*omegareal*epsilon(x[i], y[j]);
      value_epsilon =  h*h*k;
      
      diffpoints[0] =  -4.0 + h*h*k;
      diffpoints[1] = 1.0;
      diffpoints[2] = 1.0;
      diffpoints[3] = 1.0;
      diffpoints[4] = 1.0;

      if (i > 0 && i < Nx - 1 && j > 0 && j < Ny - 1) // Inre noder.
      {
        col[0] = node_idx;
        col[1] = node_idx - 1;
        col[2] = node_idx + 1;
        col[3] = node_idx - Ny;
        col[4] = node_idx + Ny;
          
        nadj = 5;
        value = h*h*right_hand_side(x[i], y[j],omegareal);

      } else // Noder på randen.
      {
        col[0] = node_idx;
        nadj   = 1;
	value  = 0.0;
      }
	  
      ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, 
		INSERT_VALUES); CHKERRQ(ierr);
      ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); 
      CHKERRQ(ierr);
      node_idx++;
    }
  }
  ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

  // Förbered för lösning av det linjära systemet.
  ierr = KSPCreate(PETSC_COMM_WORLD, &ksp); CHKERRQ(ierr);
  ierr = KSPSetOperators(ksp, A, A); CHKERRQ(ierr);

  // Bestäm förkonditioneringsmedel.
  // OBS! Variabeln omega här är inte samma variabel som 
  // frekvensvariabeln omega som används i uträkningarna.
  ierr = KSPGetPC(ksp, &preconditioner); CHKERRQ(ierr);
   
  if (method == 1)
  {
    ierr = PCSetType(preconditioner,PCJACOBI); CHKERRQ(ierr);
  } 
  else if (method == 2)
  {
    // Gauss-Seidel förkonditioneringsmedel: samma som SOR när omega=1.
    ierr = PCSetType(preconditioner, PCSOR); CHKERRQ(ierr);
  }
  else if (method == 3)
  {
    const PetscReal omega = 1.5;
    ierr = PCSetType(preconditioner, PCSOR); CHKERRQ(ierr);
    ierr = PCSORSetOmega(preconditioner, omega); CHKERRQ(ierr);
  }
  else if (method == 4)
  {
    ierr = PCSetType(preconditioner, PCBJACOBI); CHKERRQ(ierr);
  }
  else if (method == 5)
  {
    ierr = PCSetType(preconditioner, PCEISENSTAT); CHKERRQ(ierr);
  }
  else if (method == 6)
  {
    ierr = PCSetType(preconditioner, PCICC); CHKERRQ(ierr);
  }
  else if (method == 7)
  {
    ierr = PCSetType(preconditioner, PCILU); CHKERRQ(ierr);
  }
  else if (method == 8)
  {
    ierr = PCSetType(preconditioner, PCASM); CHKERRQ(ierr);
  }
  else if (method == 9)
  {
    ierr = PCSetType(preconditioner, PCGASM); CHKERRQ(ierr);
  }
  else if (method == 10)
  {
    ierr = PCSetType(preconditioner, PCGAMG); CHKERRQ(ierr);
  }
  else if (method == 11)
  {
    ierr = PCSetType(preconditioner, PCKSP); CHKERRQ(ierr);
  }
  else if (method == 12)
  {
    ierr = PCSetType(preconditioner, PCLU); CHKERRQ(ierr);
  }
  else if (method == 13)
  {
    ierr = PCSetType(preconditioner, PCCHOLESKY); CHKERRQ(ierr);
  }
    
  ierr = KSPSetFromOptions(ksp); CHKERRQ(ierr);
  ierr = KSPSolve(ksp, b, u); CHKERRQ(ierr);

  // Beräkning av det relativa felet.
  double error = 0.;
  double value_norm = 0.;  
  complex<double> value_error;

  for (int idx = 0; idx < Nsys; idx++)
  {
    ierr = VecGetValues(u, 1, &idx, &value);
    ierr = VecGetValues(exact_vector, 1, &idx, &value_exact);
    value_error = value_exact - value;	//Felet.
    value_norm += pow(real(value), 2) + pow(imag(value), 2);
    error += pow(real(value_error), 2) + pow(imag(value_error), 2);
  }    
  error = sqrt(error);
  value_norm = sqrt(value_norm);
  double relative_error = error/value_norm;
 
  if (i == 2)
  {
    ierr = VecDestroy(&b); CHKERRQ(ierr);
    ierr = VecDestroy(&exact_vector); CHKERRQ(ierr);
    ierr = VecDestroy(&u); CHKERRQ(ierr);
    ierr = MatDestroy(&A); CHKERRQ(ierr);
    ierr = KSPDestroy(&ksp); CHKERRQ(ierr);
  }
  return relative_error;
}

int dirichlet(int precond, int nr_nodes, double *returnvalues)
{
  char **argv = (char**) malloc(sizeof(char*) * 3);

  // Skapar argv och argc för initialisering av PETSC.
  int a;
  if (precond > 9)
  {
    a = 3;
  }else{
    a = 2;
  }
  int a2 = a;
  
  int temp = nr_nodes;
  int nr = nr_nodes;
  int len = 0;
  while (temp > 0)
  {
    len++;
    temp /= 10;
  }
  
  char *data = (char*) malloc(sizeof(char) * (10 + a + len + 1));
  argv[0] = &data[0];
  argv[1] = &data[11];
  argv[2] = &data[11 + a];

  strcpy(argv[0], "./runconv2");
  
  a--;
  data[11 + a] = '\0';
  a--;
  if (a == 1)
  {
    data[11] = precond / 10 + '0';
    data[12] = precond % 10 + '0';
  }
  else
  {
    data[11] = precond + '0';
  }

  cout << "argv0 = " << argv[0] << "\nargv1 = " <<  argv[1] << endl;

  for (int i = len - 1; i >= 0; i--)
  {
    data[11 + a2 + i] = nr % 10 + '0';
    nr /= 10;
  }
  data[11 + a2 + len] = '\0';

  cout << "argv2 = " << argv[2] << endl;
  
  int argc = 3;

  PetscErrorCode ierr;
 
  // Initialisering av PETSC.
  ierr = PetscInitialize(&argc, &argv,(char *)0, help);CHKERRQ(ierr);
  
  PetscInt method =  (PetscInt) precond;
  PetscBool methodSet = PETSC_FALSE;
 
  ierr = PetscOptionsGetInt(NULL, NULL, "-m", &method, &methodSet);
  if (method < 1 || method > 13) 
  {
    cout << "Invalid number of the selected method: "
	<< method << ".\nExiting..." << endl;
    exit(-1);
  }

  PetscPrintf(PETSC_COMM_WORLD, "Using %s\n", GetMethodName(method));
  
  // Förbereder variabler.
  Vec b, u, exact_vector;
  Mat A;
  KSP ksp;
  PC preconditioner;
  PetscInt Nx = nr_nodes, Ny = Nx, Nsys, node_idx = 0, col[5], nadj;

  Nsys = Nx*Ny; // Det linjära systemets dimension = antalet noder.
  PetscReal x[Nx], y[Ny], nodes[Nsys][2];
  PetscScalar value, value_epsilon, value_exact,value_error, diffpoints[5], h;
   
  // Deklarering av vektorer.
  ierr = VecCreate(PETSC_COMM_WORLD, &b); CHKERRQ(ierr);
  ierr = VecSetSizes(b, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
  ierr = VecSetType(b, VECSTANDARD); CHKERRQ(ierr);
  ierr = VecDuplicate(b, &u);
 
  ierr = VecCreate(PETSC_COMM_WORLD, &exact_vector); CHKERRQ(ierr);
  ierr = VecSetSizes(exact_vector, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
  ierr = VecSetType(exact_vector, VECSTANDARD); CHKERRQ(ierr);
  ierr = VecDuplicate(exact_vector, &u);
  
  // Deklarering av matris A.
  ierr = MatCreate(PETSC_COMM_WORLD, &A); CHKERRQ(ierr);
  ierr = MatSetSizes(A,PETSC_DECIDE, PETSC_DECIDE, Nsys, Nsys); CHKERRQ(ierr);
  ierr = MatSetFromOptions(A); CHKERRQ(ierr);
  ierr = MatSetUp(A); CHKERRQ(ierr);

  // Skapar nätet.
  h = 1.0/(Nx - 1);
  for (int i = 0; i < Nx; i++)
    x[i] = 1.0*i/(Nx - 1);
  for (int j = 0; j < Ny; j++)
    y[j] = 1.0*j/(Ny - 1);
  
  // Beräknar den exakta lösningen och den numeriska approximationen.
  exactCalcD(exact_vector, value_exact, ierr, node_idx, Nx, Ny, x, y);
  
  PetscScalar k;
  double error = calculationsD(method, omega, 1, b, u, exact_vector, A, ksp, 
	preconditioner, Nx, Ny, Nsys, node_idx, col, nadj, x, y, nodes, value, 
	value_epsilon, value_exact, diffpoints, h, ierr, k);

  returnvalues[0] = error; //Det relativa felet.
  returnvalues[1] = omega;
    
  free(argv);
  free(data);
  return 0;
}

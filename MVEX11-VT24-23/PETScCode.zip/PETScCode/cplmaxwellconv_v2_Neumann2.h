static char help[] ="";
#include<iostream>
#include<fstream>
#include<petsc.h>
#include<petscvec.h>
#include<petscmat.h>
#include<petscksp.h>
#include<complex>
#include<math.h>
#include<thread>
#include<vector>
#include<cmath>

using namespace std;
  
double omega = 100.; //Ändra detta värde efter behov.

char METHOD_NAMES[15][70] = {
    "Ogiltig metod",
    "Jacobi",
    "Gauss-Seidel",
    "SOR",
    "Block Jacobi",
    "SOR med Eisenstats trick",
    "Ofullständig Cholesky",
    "Ofullständig LU",
    "Additiv Schwarz",
    "Generaliserad Additiv Schwarz",
    "Algebraic Multigrid",
    "Linjär lösare",
    "LU",
    "Cholesky"};

char *GetMethodName(PetscInt method) {
    if (method < 0 || method > 13)
        return METHOD_NAMES[0];
    else
        return METHOD_NAMES[method];
}

PetscScalar   epsilon(const PetscReal x, const PetscReal y)
{
  PetscReal rpart, ipart;

  PetscReal x_0=0.5;
  PetscReal y_0=0.5;
  PetscReal c_x=1;
  PetscReal c_y=1;

  rpart = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));
  ipart = 0;    

  PetscScalar scalareps(rpart, ipart);
  return scalareps;
}

PetscScalar right_hand_side(const PetscReal x, const PetscReal y, 
	const PetscReal omega)
{
  PetscReal rpart, ipart, pi = 3.14159265359;

  PetscReal x_0=0.5;
  PetscReal y_0=0.5;
  PetscReal c_x=1;
  PetscReal c_y=1;
  PetscReal epsilon_real = 2 * exp(-((x-x_0 ) * (x-x_0) / (2*c_x*c_x) +
	(y-y_0) * (y-y_0) / (2*c_y*c_y)));
 
  //Testfunktion 1:
  //rpart =  -(8*pi*pi) * sin(2*pi*x) * sin(2*pi*y) + omega*omega * 
  	//epsilon_real * (sin(2*pi*x)*sin(2*pi*y));
  //ipart = -2*(x - x*x + y - y*y) + omega*omega*epsilon_real*x*(1-x)*y*(1-y);

  //Testfunktion 2:
  rpart =  -2 * pi*pi * cos(pi*x) * cos(pi*y) + omega*omega * epsilon_real * 
	  cos(pi*x) * cos(pi*y);
  ipart = (2*x - 1) * (y*y*y / 3 - y*y / 2) + (x*x*x / 3 - x*x / 2) * (2*y - 1) 
	  + omega*omega * epsilon_real * (x*x*x / 3 - x*x / 2) 
	  * (y*y*y / 3 - y*y / 2);
    
  PetscScalar f(rpart, ipart);
  return f;
}

PetscScalar  exact_solution(const PetscReal x, const PetscReal y)
{
  PetscReal rpart, ipart, pi = 3.14159265359;

  //Testfunktion 1:
  //rpart = sin(2*pi*x)*sin(2*pi*y);
  //ipart = x*(1-x)*y*(1-y);
  
  //Testfunktion 2:
  rpart = cos(pi*x)*cos(pi*y);
  ipart = (x * x * x / 3 - x * x / 2) * (y * y * y / 3 - y * y / 2);
    
  PetscScalar f(rpart, ipart);
  return f;
}

int exactCalc(Vec exact_vector, PetscScalar value_exact, PetscErrorCode ierr, 
	PetscInt node_idx, PetscInt Nx, PetscInt Ny, PetscReal x[], 
	PetscReal y[])
{
  node_idx = 0;
  for (int i = 0; i < Nx; i++)
  {
    for (int j = 0; j < Ny; j++)
    {
      value_exact = exact_solution(x[i], y[j]);
      ierr = VecSetValues(exact_vector, 1, &node_idx, &value_exact, 
		INSERT_VALUES); 
      CHKERRQ(ierr);
      node_idx++;
    }
  }
  return 0;
}

double calculations(int method, double omegareal, int check_or_finalize, Vec b, 
	Vec u, Vec exact_vector, Mat A, KSP ksp, PC preconditioner, PetscInt Nx, 
	PetscInt Ny, PetscInt Nsys, PetscInt node_idx, PetscInt col[], 
	PetscInt nadj, PetscReal x[], PetscReal y[], PetscReal nodes[][2], 
	PetscScalar value, PetscScalar value_epsilon, PetscScalar value_exact, 
	PetscScalar value_error, PetscScalar diffpoints[], PetscScalar h, 
	PetscErrorCode ierr, PetscScalar k, int last_time)
{
  // Skapar den diskretiserade differentialekvationen i de inre noderna
  // (m.hj.a."five-point stencil") och lägger in dessa i A. Räknar ut 
  // högerledets värden och lägger in i b.
  for (int i = 1; i < Nx-1  ; i++)
  {
    for (int j = 1; j < Ny-1  ; j++)
    {	
      int node_idx = j * Nx + i; //Globalt index för nuvarande nod. 
 		
      //Nodernas placering i koordinatsystemet.
      nodes[node_idx][0] = x[i];    
      nodes[node_idx][1] = y[j];

      k = omegareal * omegareal * epsilon(x[i], y[j]);
      value_epsilon = h * h * k;

      // Koefficienter till de u_{i,j} som specificeras i vektorn col.
      diffpoints[0] = -4.0 + h * h * k;
      diffpoints[1] = 1.0;
      diffpoints[2] = 1.0;
      diffpoints[3] = 1.0;
      diffpoints[4] = 1.0;

      // Index för de u_{i,j} som ingår i den diskretiserade 
      // differentialekvationen i punkten. 
      col[0] = node_idx; // Nuvarande index. 
      col[1] = node_idx - 1; // Ett steg till vänster.
      col[2] = node_idx + 1; // Ett steg till höger.
      col[3] = node_idx - Ny; // Ett steg nedåt.
      col[4] = node_idx + Ny; // Ett steg uppåt.

      nadj = 5;	// Antal grannar som används i diskretiseringen, 
      		// inklusive nuvarande nod.
      value = h * h * right_hand_side(x[i], y[j], omegareal); //Högerledet.

      ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, 
		INSERT_VALUES); 
      CHKERRQ(ierr);
      ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); 
      CHKERRQ(ierr);
    }
  }

  // Implementerar första ordningens approx. av Neumanns BC på vänster sida, 
  // exklusive hörnnoderna.  
  for (int j = 1; j < Ny - 1; j++)
  {
    int node_idx = j * Nx;

    nodes[node_idx][0] = x[0];
    nodes[node_idx][1] = y[j];

    k = omegareal * omegareal * epsilon(x[0], y[j]);
    value_epsilon = h * h * k;

    diffpoints[0] = -4.0 + h * h * k;
    diffpoints[1] = 2;  
    diffpoints[2] = 1.0;
    diffpoints[3] = 1.0;

    col[0] = node_idx;
    col[1] = node_idx + 1;
    col[2] = node_idx - Ny;
    col[3] = node_idx + Ny;

    nadj = 4;
    value = h * h * right_hand_side(x[0], y[j], omegareal);

    ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); 
    CHKERRQ(ierr); 
    ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);
  }
       
  // Implementerar första ordningens approx. av Neumanns BC på höger sida, 
  // exklusive hörnnoderna.
  for (int j = 1; j < Ny - 1; j++)
  {
    int node_idx = (Ny-1) + j*Nx;    

    nodes[node_idx][0] = x[Nx-1];
    nodes[node_idx][1] = y[j];

    k = omegareal * omegareal * epsilon(x[Nx-1], y[j]);
    value_epsilon = h * h * k;

    diffpoints[0] = -4.0 + h * h * k;
    diffpoints[1] = 2;    
    diffpoints[2] = 1.0;  
    diffpoints[3] = 1.0;  

    col[0] = node_idx;
    col[1] = node_idx - 1;
    col[2] = node_idx - Ny;
    col[3] = node_idx + Ny;

    nadj = 4;
    value = h * h * right_hand_side(x[Nx-1], y[j], omegareal);

    ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); 
    CHKERRQ(ierr); 
    ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);
  }

  // Implementerar första ordningens approx. av Neumanns BC på den övre sidan, 
  // exklusive hörnnoderna.
  for (int i = 1; i < Nx - 1; i++)  
  {
    int node_idx = (Ny-1) * Nx + i;

    nodes[node_idx][0] = x[i];
    nodes[node_idx][1] = y[Ny-1];

    k = omegareal * omegareal * epsilon(x[i], y[Ny-1]);
    value_epsilon = h * h * k;

    diffpoints[0] = -4.0 + h * h * k;
    diffpoints[1] = 1;
    diffpoints[2] = 1;
    diffpoints[3] = 2;

    col[0] = node_idx;
    col[1] = node_idx - 1;
    col[2] = node_idx + 1;
    col[3] = node_idx - Ny;  

    nadj = 4;
    value = h * h * right_hand_side(x[i], y[Ny-1], omegareal);

    ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); 
    CHKERRQ(ierr); 
    ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);
  }

  // Implementerar första ordningens approx. av Neumanns BC på den nedre sidan, 
  // exklusive hörnnoderna.
  for (int i = 1; i < Nx - 1; i++)  
  {
    int node_idx = i;

    nodes[node_idx][0] = x[i];
    nodes[node_idx][1] = y[0];

    k = omegareal * omegareal * epsilon(x[i], y[0]);
    value_epsilon = h * h * k;

    diffpoints[0] = -4.0 + h * h * k;
    diffpoints[1] = 1;
    diffpoints[2] = 1;
    diffpoints[3] = 2;

    col[0] = node_idx;
    col[1] = node_idx - 1;
    col[2] = node_idx + 1;
    col[3] = node_idx + Ny;

    nadj = 4;
    value = h * h * right_hand_side(x[i], y[0], omegareal);

    ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); 
    CHKERRQ(ierr); 
    ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);
  }

  // Behandling av hörnnoderna.
  // Övre, vänstra hörnet.
  node_idx = Nx * (Ny-1);
  nodes[node_idx][0] = x[0];   
  nodes[node_idx][1] = y[Ny-1];

  k = omegareal * omegareal * epsilon(x[0], y[Ny-1]);
  value_epsilon = h * h * k;

  diffpoints[0] = -4.0 + h * h * k;
  diffpoints[1] = 2;
  diffpoints[2] = 2;

  col[0] = node_idx;
  col[1] = node_idx + 1;
  col[2] = node_idx - Ny;

  nadj = 3;
  value = h * h * right_hand_side(x[0], y[Ny-1], omegareal);

  ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); 
  CHKERRQ(ierr);
  ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);
    
  // Övre, högra hörnet.
  node_idx = (Nx * Ny) - 1 ;
  nodes[node_idx][0] = x[Nx-1];    
  nodes[node_idx][1] = y[Ny-1];

  k = omegareal * omegareal * epsilon(x[Nx], y[Ny]); 
  value_epsilon = h * h * k;

  diffpoints[0] = -4.0 + h * h * k;
  diffpoints[1] = 2;
  diffpoints[2] = 2;

  col[0] = node_idx;
  col[1] = node_idx - 1;
  col[2] = node_idx - Ny;

  nadj = 3;
  value = h * h * right_hand_side(x[Nx - 1], y[Ny-1], omegareal);

  ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); 
  CHKERRQ(ierr);
  ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);

  // Nedre, högra hörnet.        
  node_idx  = Nx - 1;
  nodes[node_idx][0] = x[Nx-1];
  nodes[node_idx][1] = y[0];

  k = omegareal * omegareal * epsilon(x[Nx-1], y[0]);
  value_epsilon = h * h * k;

  diffpoints[0] = -4.0 + h * h * k;
  diffpoints[1] = 2;
  diffpoints[2] = 2;

  col[0] = node_idx;
  col[1] = node_idx - 1;
  col[2] = node_idx + Ny;

  nadj = 3;
  value = h * h * right_hand_side(x[Nx - 1], y[0], omegareal);

  ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); 
  CHKERRQ(ierr);
  ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);

  // Nedre, vänstra hörnet.
  node_idx = 0;
  nodes[node_idx][0] = x[0];
  nodes[node_idx][1] = y[0];

  k = omegareal * omegareal * epsilon(x[0], y[0]);
  value_epsilon = h * h * k;


  diffpoints[0] = -4.0 + h * h * k;
  diffpoints[1] = 2;
  diffpoints[2] = 2;

  col[0] = node_idx;
  col[1] = node_idx + 1;
  col[2] = node_idx + Ny;

  nadj = 3;
  value = h * h * right_hand_side(x[0], y[0], omegareal);

  ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); 
  CHKERRQ(ierr);
  ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);

  ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);


  ierr = KSPSetOperators(ksp, A, A); CHKERRQ(ierr);

  // Bestäm förkonditioneringsmedel. 
  // OBS! Variabeln omega här är inte samma variabel som 
  // frekvensvariabeln omega som används i uträkningarna.
  ierr = KSPGetPC(ksp, &preconditioner); CHKERRQ(ierr);
   
  if (method == 1)
  {
     ierr = PCSetType(preconditioner,PCJACOBI); CHKERRQ(ierr);     
  }
  else if (method == 2)
  {
    // Gauss-Seidel förkonditioneringsmedel: samma som SOR när omega=1.
    ierr = PCSetType(preconditioner, PCSOR); 	
    CHKERRQ(ierr);
  }
  else if (method == 3)
  {
    const PetscReal omega = 1.5;
    ierr = PCSetType(preconditioner, PCSOR); CHKERRQ(ierr);
    ierr = PCSORSetOmega(preconditioner, omega); CHKERRQ(ierr);
  }
  else if (method == 4)
  {
    ierr = PCSetType(preconditioner,PCBJACOBI);CHKERRQ(ierr);	    
  }

  else if (method == 5)
  {
    ierr = PCSetType(preconditioner,PCEISENSTAT);CHKERRQ(ierr);	    
  }
 
  else if (method == 6)
  {
    ierr = PCSetType(preconditioner,PCICC);CHKERRQ(ierr);	    
  }
  else if (method == 7)
  {
    ierr = PCSetType(preconditioner,PCILU);CHKERRQ(ierr);	    
  }
  else if (method == 8)
  {
    ierr = PCSetType(preconditioner,PCASM);CHKERRQ(ierr);	    
  }
  else if (method == 9)
  {
    ierr = PCSetType(preconditioner,PCGASM);CHKERRQ(ierr);	    
  }
  else if (method == 10)
  {
    ierr = PCSetType(preconditioner,PCGAMG);CHKERRQ(ierr);	    
  }
  else if (method == 11)
  {
    ierr = PCSetType(preconditioner,PCKSP);CHKERRQ(ierr);	    
  }
  else if (method == 12)
  {
    ierr = PCSetType(preconditioner,PCLU);CHKERRQ(ierr);	    
  }
  else if (method == 13)
  {
    ierr = PCSetType(preconditioner,PCCHOLESKY);CHKERRQ(ierr);	    
  }
  else if (method == 14)
  {
    PetscInt maxIt = 1000;
    ierr = KSPSetTolerances(ksp,PETSC_DEFAULT, PETSC_DEFAULT, PETSC_DEFAULT,
	maxIt); CHKERRQ(ierr);
    ierr = PCSetType(preconditioner,PCNONE);CHKERRQ(ierr);	    
  }

  ierr = KSPSetFromOptions(ksp); CHKERRQ(ierr);
  ierr = KSPSolve(ksp, b, u); CHKERRQ(ierr);

  // Beräkning av det relativa felet.
  double error = 0;
  double value_norm = 0;

  for (int idx = 0; idx < Nsys; idx++)
  {
    ierr = VecGetValues(u, 1, &idx, &value);
    ierr = VecGetValues(exact_vector, 1, &idx, &value_exact);
    value_error =   value_exact - value;  //Felet.
    value_norm = value_norm + pow(real(value), 2) + pow(imag(value), 2);
    error = error + pow(real(value_error), 2) + pow(imag(value_error), 2);
  }
  error = sqrt(error);
  value_norm = sqrt(value_norm);
  double relative_error = error/value_norm;
  
  if (check_or_finalize == 2)
  {
  // Clean up
    ierr = VecDestroy(&b); CHKERRQ(ierr);
    ierr = VecDestroy(&exact_vector); CHKERRQ(ierr);
    ierr = VecDestroy(&u); CHKERRQ(ierr);
    ierr = MatDestroy(&A); CHKERRQ(ierr);
    ierr = KSPDestroy(&ksp); CHKERRQ(ierr);

    if (last_time == 1)
    {
      ierr = PetscFinalize();
    }
  }
  return relative_error;
}

int neumann2(int precond, int nr_nodes, double *returnvalues, int last_time)
{
  // Skapar argv och argc för initialisering av PETSC.
  char **argv = (char**) malloc(sizeof(char*) * 3);
  int a;

  if (precond > 9)
  {
    a = 3;
  }else{
    a = 2;
  }

  int a2 = a;
  int temp = nr_nodes;
  int nr = nr_nodes;
  int len = 0;
  
  while (temp > 0)
  {
    len++;
    temp /= 10;
  }
  
  char *data = (char*) malloc(sizeof(char) * (10 + a + len + 1));
  argv[0] = &data[0];
  argv[1] = &data[11];
  argv[2] = &data[11 + a];
  strcpy(argv[0], "./runconv2");
  
  a--;
  data[11 + a] = '\0';
  a--;
  if (a == 1)
  {
    data[11] = precond / 10 + '0';
    data[12] = precond % 10 + '0';
  }
  else
  {
    data[11] = precond + '0';
  }

  cout << "argv0 = " << argv[0] << "\nargv1 = " <<  argv[1] << endl;

  for (int i = len - 1; i >= 0; i--)
  {
    data[11 + a2 + i] = nr % 10 + '0';
    nr /= 10;
  }
  data[11 + a2 + len] = '\0';

  cout << "argv2 = " << argv[2] << endl;
  
  int argc = 3;

  PetscErrorCode ierr;

  // Initialisering av PETSC.
  ierr = PetscInitialize(&argc, &argv, (char*)0, help); CHKERRQ(ierr);

  PetscInt method = (PetscInt) precond;
  PetscBool methodSet = PETSC_FALSE;

  ierr = PetscOptionsGetInt(NULL, NULL, "-m", &method, &methodSet);
  if (method < 1 || method > 13) 
  {
     cout << "Invalid number of the selected method: "
     << method << ".\nExiting..." << endl;
     exit(-1);
  }

  Vec b, u, exact_vector;
  Mat A;
  KSP ksp;
  PC preconditioner;
  PetscInt Nx = nr_nodes, Ny = Nx, Nsys, node_idx, col[5], nadj;

  Nsys = Nx*Ny; // Det linjära systemets dimension = antalet noder.
  PetscReal x[Nx], y[Ny], nodes[Nsys][2];
  PetscScalar value, value_epsilon, value_exact, value_error, diffpoints[5], h;

  // Deklarering av vektorer.
  ierr = VecCreate(PETSC_COMM_WORLD, &b); CHKERRQ(ierr);
  ierr = VecSetSizes(b, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
  ierr = VecSetType(b, VECSTANDARD); CHKERRQ(ierr);
  ierr = VecDuplicate(b, &u);

  ierr = VecCreate(PETSC_COMM_WORLD, &exact_vector); CHKERRQ(ierr);
  ierr = VecSetSizes(exact_vector, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
  ierr = VecSetType(exact_vector, VECSTANDARD); CHKERRQ(ierr);
  ierr = VecDuplicate(exact_vector, &u);

  // Deklarering av matris A.
  ierr = MatCreate(PETSC_COMM_WORLD, &A); CHKERRQ(ierr);
  ierr = MatSetSizes(A, PETSC_DECIDE, PETSC_DECIDE, Nsys, Nsys); CHKERRQ(ierr);
  ierr = MatSetFromOptions(A); CHKERRQ(ierr);
  ierr = MatSetUp(A); CHKERRQ(ierr);
  
  // Skapar ksp.
  ierr = KSPCreate(PETSC_COMM_WORLD, &ksp); CHKERRQ(ierr);

  // Skapar nätet.
  h = 1.0 / (Nx - 1);
  for (int i = 0; i < Nx; i++)
      x[i] = 1.0 * i / (Nx - 1);
  for (int j = 0; j < Ny; j++)
      y[j] = 1.0 * j / (Ny - 1);

  // Beräknar den exakta lösningen och den numeriska approximationen.
  exactCalc(exact_vector, value_exact, ierr, node_idx, Nx, Ny, x, y);

  PetscScalar k;
    
  double error = calculations(method, omega, 1, b, u, exact_vector, A, ksp, 
	preconditioner, Nx, Ny, Nsys, node_idx, col, nadj, x, y, nodes, value, 
	value_epsilon, value_exact, value_error, diffpoints, h, ierr, k, 0);
  
  cout << "omega är " << omega << endl;
  
  returnvalues[0] = error;  // Det relativa felet.
  returnvalues[1] = omega;
  free(argv);
  free(data);
  return 0;
}



// to compile:
// runneumdir argv[1] argv[2]  argv[3] argv[4]
// Arguments:
// argv[1] - preconditioner (should be 1,2,3,4; the best one 3: SOR)
// argv[2] - number of discretization points in x and y directions
// argv[3] - real value of omega
// argv[4] - sequence which specifies the boundary 1 is Neumann, 2 is Dirichlet, the sequence needs to be 4 numbers long for every edge on the unit square

static char help[] ="";
#include<iostream>
#include<fstream>
#include<petsc.h>
#include<petscvec.h>
#include<petscmat.h>
#include<petscksp.h>
#include<complex>
#include<vector>
#include<string>

using namespace std;

char METHOD_NAMES[8][70] = {
	"invalid method",
	"Jacobi's method",
	"Gauss-Seidel method",
	"Successive Overrelaxation method (SOR)",
	"Linear Solver"
};

char *GetMethodName(PetscInt method) {
	if (method < 0 || method > 4)
		return METHOD_NAMES[0];
	else
		return METHOD_NAMES[method];
}

PetscScalar   epsilon(const PetscReal x, const PetscReal y)
{


	PetscReal rpart, ipart;

	PetscReal x_0=0.5;
	PetscReal y_0=0.5;
	PetscReal c_x=1;
	PetscReal c_y=1;

	rpart = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));

	ipart = 0;    

	PetscScalar scalareps(rpart, ipart);

	return scalareps;
}

PetscScalar right_hand_side(const PetscReal x, const PetscReal y, const PetscReal omega) {
	PetscReal rpart, ipart, pi = 3.14159265359;
	PetscReal x_0=0.5;
	PetscReal y_0=0.5;
	PetscReal c_x=1;
	PetscReal c_y=1;

	PetscReal epsilon_real = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));

	rpart =  (-2*pi*pi + omega*omega*epsilon_real)*cos(pi*x)*cos(pi*y);

	ipart = (2*x - 1)*(y*y*y/3 - y*y/2) + (2*y - 1)*(x*x*x/3 - x*x/2) + omega*omega*epsilon_real*(x*x*x/3 - x*x/2)*(y*y*y/3 - y*y/2);

	PetscScalar f(rpart, ipart);

	return f;
}

int main(int argc, char **argv) {
	PetscErrorCode ierr;

	cout << "Initializing ..." << endl;

	ierr = PetscInitialize(&argc, &argv,(char *)0, help);CHKERRQ(ierr);

	PetscInt method =  atoi(argv[1]);
	PetscBool methodSet = PETSC_FALSE;

	ierr = PetscOptionsGetInt(NULL, NULL, "-m", &method, &methodSet);

	if (method < 1 || method > 7) {
		cout << "Invalid number of the selected method: " << method << ".\nExiting..." << endl;
		exit(-1);
	}

	PetscPrintf(PETSC_COMM_WORLD, "Using %s\n", GetMethodName(method));

	cout << "Setting parameters..." << endl;

	Vec b, u;
	Mat A;
	KSP ksp;
	PC preconditioner;
	PetscInt Nx = atoi(argv[2]), Ny = Nx, Nsys, node_idx = 0, nadj;
	Nsys = Nx*Ny; // dimesnsion of linear system = number of nodes
	PetscReal x[Nx], y[Ny], nodes[Nsys][2];
	PetscScalar value, value_epsilon, diffpoints[5], h;

	// Set up vectors
	cout << "Setting up vectors..." << endl;
	ierr = VecCreate(PETSC_COMM_WORLD, &b); CHKERRQ(ierr);
	ierr = VecSetSizes(b, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
	ierr = VecSetType(b, VECSTANDARD); CHKERRQ(ierr);
	ierr = VecDuplicate(b, &u);

	// Set up matrix
	cout << "Setting up matrix..." << endl;
	ierr = MatCreate(PETSC_COMM_WORLD, &A); CHKERRQ(ierr);
	ierr = MatSetSizes(A,PETSC_DECIDE, PETSC_DECIDE, Nsys, Nsys); CHKERRQ(ierr);
	ierr = MatSetFromOptions(A); CHKERRQ(ierr);
	ierr = MatSetUp(A); CHKERRQ(ierr);

	// Create grid
	cout << "Constructing grid..." << endl;
	h = 1.0/(Nx - 1);
	for (int i = 0; i < Nx; i++)
		x[i] = 1.0*i/(Nx - 1);
	for (int j = 0; j < Ny; j++)
		y[j] = 1.0*j/(Ny - 1);

	// Assemble linear system ...
	cout << "Assembling system..." << endl;

	PetscScalar k;
	double omegareal=atoi(argv[3]);

	// Boundary int for the four edges
	PetscInt left_bdry = 0;
	PetscInt right_bdry = 0;
	PetscInt bottom_bdry = 0;
	PetscInt top_bdry = 0;

	int bdry = atoi(argv[4]);
	// convert 4 digit number to string and read of its value. 
	// If it is one, change the boundary index to Neumann otherwise leave it as Dirichlet
	char bdry_string[500];
	sprintf(bdry_string, "%d", bdry);

	cout<<bdry<<endl;
	cout << bdry_string<<endl;
	for (int t = 0; t < 4; ++t) {
		char digit = bdry_string[t];
		if (digit == '1') {
			if(t == 0){
				bottom_bdry = 1;
			}else if (t == 1) {
				left_bdry = 1;	
			}else if (t == 2) {
				top_bdry = 1;
			}else {
				right_bdry = 1;
			}
		} 
	}

	std::vector<PetscInt> col;

	for (int i = 0; i < Nx; i++) {

		for (int j = 0; j < Ny; j++) {

			nodes[node_idx][0] = x[i];
			nodes[node_idx][1] = y[j];

			k = omegareal*omegareal*epsilon(x[i], y[j]);

			if (i == 0 || i == Nx - 1 || j == 0 || j == Ny - 1) { //boundary

				if ((i == 0 && (j == 0 || j == Ny - 1)) || (i == Nx - 1 && (j == 0 || j == Ny - 1))) { //corners

					nadj = 3; 
					col.resize(3);

					diffpoints[0] = -1.0 + h*h*k;
					diffpoints[1] = 0.5;	
					diffpoints[2] = 0.5;	

					if (i == 0) { // bottom corners
						col[0] = node_idx;
						if(j == 0) { //left
							if(left_bdry != 0 && bottom_bdry != 0) {
								col[1] = node_idx + Ny; 
								col[2] = node_idx + 1;
								value = h*h*right_hand_side(x[i], y[j], omegareal)/1.0;
							} else {
								nadj = 1;
								value = 0;
							}
						} else { //right
							if(right_bdry != 0 && bottom_bdry != 0) {
								col[1] = node_idx + Ny; 
								col[2] = node_idx - 1;
								value = h*h*right_hand_side(x[i], y[j], omegareal)/1.0;
							} else {
								nadj = 1;
								value = 0;
							}
						}

					} else { //top corners 

						col[0] = node_idx;
						if(j == 0) { //left
							//cout<<"i!0j=0"<<node_idx<<endl;
							if(left_bdry != 0 && top_bdry != 0) {
								col[1] = node_idx - Ny; 
								col[2] = node_idx + 1;
								value = h*h*right_hand_side(x[i], y[j], omegareal)/1.0;
							} else {
								nadj = 1;
								value = 0;
							}
						} else { //right
							//cout<<"i!0j!0"<<node_idx<<endl;
							if(right_bdry != 0 && top_bdry != 0) {
								col[1] = node_idx - Ny; 
								col[2] = node_idx - 1;
								value = h*h*right_hand_side(x[i], y[j], omegareal)/1.0;
							} else {
								nadj = 1;
								value = 0;
							}
						}
					}

				} else { // boundary points (excluding corners)

					nadj = 4; 
					//value = h*h*right_hand_side(x[i], y[j], omegareal)/1.0; 
					col.resize(4);
					diffpoints[0] = -2.0 + h*h*k;
					diffpoints[1] = 1.0;
					diffpoints[2] = 0.5;
					diffpoints[3] = 0.5;	

					if (i == 0) { //bottom boundary
						col[0] = node_idx;
						if (bottom_bdry != 0) {
							col[1] = node_idx + Ny;
							col[2] = node_idx - 1;
							col[3] = node_idx + 1; 
							value = h*h*right_hand_side(x[i], y[j], omegareal); 
						} else {
							nadj = 1;
							value = 0;
						}

					} else if (i == Nx - 1) { // top boundary

						col[0] = node_idx;
						if (top_bdry != 0) {
							col[1] = node_idx - Ny;
							col[2] = node_idx - 1;
							col[3] = node_idx + 1; 
							value = h*h*right_hand_side(x[i], y[j], omegareal);  
						} else {
							nadj = 1;
							value = 0;
						}

					} else if (j == 0) { //left boundary

						col[0] = node_idx;
						if (left_bdry != 0) {
							col[1] = node_idx + 1;
							col[2] = node_idx - Ny;
							col[3] = node_idx + Ny; 
							value = h*h*right_hand_side(x[i], y[j], omegareal);
						} else {
							nadj = 1;
							value = 0;
						}

					} else { //right bdry

						col[0] = node_idx;
						if (right_bdry != 0) {
							col[1] = node_idx - 1;
							col[2] = node_idx - Ny;
							col[3] = node_idx + Ny; 
							value = h*h*right_hand_side(x[i], y[j], omegareal);
						} else {
							nadj = 1;
							value = 0;
						}
					}

				}

			} else { //interior

				nadj = 5; value = h*h*right_hand_side(x[i], y[j], omegareal); 
				col.resize(5);

				diffpoints[0] = -4.0 + h*h*k;	col[0] = node_idx;
				diffpoints[1] = 1.0;		col[1] = node_idx - 1;
				diffpoints[2] = 1.0;		col[2] = node_idx + 1;
				diffpoints[3] = 1.0;		col[3] = node_idx - Ny;
				diffpoints[4] = 1.0;		col[4] = node_idx + Ny;

			}

			ierr = MatSetValues(A, 1, &node_idx, nadj, col.data(), diffpoints, INSERT_VALUES); CHKERRQ(ierr);
			ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);

			node_idx++;

		}

	}

	ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
	ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

	// Solve linear system
	cout << "Solving linear system ..." << endl;
	ierr = KSPCreate(PETSC_COMM_WORLD, &ksp); CHKERRQ(ierr);
	ierr = KSPSetOperators(ksp, A, A); CHKERRQ(ierr);

	// set preconditioner 
	ierr = KSPGetPC(ksp, &preconditioner); CHKERRQ(ierr);

	if (method == 1) {
		ierr =	PCSetType(preconditioner,PCJACOBI); CHKERRQ(ierr);
	} else if (method == 2) {
		ierr = PCSetType(preconditioner, PCSOR); 	
		CHKERRQ(ierr);
	} else if (method == 3) {
		const PetscReal omega = 1.5;
		ierr = PCSetType(preconditioner, PCSOR); CHKERRQ(ierr);
		ierr = PCSORSetOmega(preconditioner, omega); CHKERRQ(ierr);
	} else if (method == 4) {
		ierr = PCSetType(preconditioner, PCKSP); 	
		CHKERRQ(ierr);
	}


	ierr = KSPSetFromOptions(ksp); CHKERRQ(ierr);
	ierr = KSPSolve(ksp, b, u); CHKERRQ(ierr);

	// Print to files
	cout << "Writing to files..." << endl;
	FILE* nodefile = fopen("nodes.m", "w");
	for (int idx = 0; idx < Nsys; idx++)
		fprintf(nodefile, "%f \t %f \n", nodes[idx][0], nodes[idx][1]);
	fclose(nodefile);
	FILE* solfile = fopen("values.m", "w");
	for (int idx = 0; idx < Nsys; idx++) {
		ierr = VecGetValues(u, 1, &idx, &value);
		fprintf(solfile, "%f \t %f \n", real(value), imag(value));
	}
	fclose(solfile);

	// Clean up
	ierr = VecDestroy(&b); CHKERRQ(ierr);
	ierr = VecDestroy(&u); CHKERRQ(ierr);
	ierr = MatDestroy(&A); CHKERRQ(ierr);
	ierr = KSPDestroy(&ksp); CHKERRQ(ierr);

	// Finalize and finish
	ierr = PetscFinalize();
	return 0;
}


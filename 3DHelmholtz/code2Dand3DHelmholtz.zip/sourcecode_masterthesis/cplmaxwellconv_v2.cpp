// to compile:
// runmaxwellv2 argv[1] argv[2] argv[3] argv[4]
// Arguments:
// argv[1] - preconditioner (should be 1,2,3,4,5,6,7,8)
// argv[2] - number of discretization points in x and y directions
// argv[3] - frequency omega
// argv[4] - alpha of the damping term

static char help[] ="";
#include<iostream>
#include<fstream>
#include<petsc.h>
#include<petscvec.h>
#include<petscmat.h>
#include<petscksp.h>
#include<complex>
#include<ctime>
#include<cmath>

using namespace std;

char METHOD_NAMES[10][70] = {
	"invalid method",
	"Jacobi's method",
	"Gauss-Seidel method",
	"Successive Overrelaxation method (SOR)",
	"Algebraic Multigrid",
	"Additive schwarz",
	"Incomplete cholesky",
	"no preconditioner"};

char *GetMethodName(PetscInt method) {
	if (method < 0 || method > 8)
		return METHOD_NAMES[0];
	else
		return METHOD_NAMES[method];
}


PetscScalar   epsilon(const PetscReal x, const PetscReal y)
{
	PetscReal rpart, ipart;

	PetscReal x_0=0.5;
	PetscReal y_0=0.5;
	PetscReal c_x=1;
	PetscReal c_y=1;

	rpart = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));

	ipart = 0;    

	PetscScalar scalareps(rpart, ipart);
	return scalareps;

}

PetscScalar   stabilization(const PetscReal omega, const PetscReal alpha )
{
  PetscReal rpart, ipart;
  rpart = 0.0;
  ipart = omega*alpha;

    
  PetscScalar f(rpart, ipart);
  return f;
}


PetscScalar right_hand_side(const PetscReal x, const PetscReal y,
		const PetscReal omega)
{
	PetscReal rpart, ipart, pi = 3.14159265359;


	PetscReal x_0=0.5;
	PetscReal y_0=0.5;
	PetscReal c_x=1;
	PetscReal c_y=1;
	PetscReal epsilon_real = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));
	rpart =  -(8*pi*pi)*sin(2*pi*x)*sin(2*pi*y)+ omega*omega*epsilon_real*(sin(2*pi*x)*sin(2*pi*y));

	ipart = -2*(x - x*x + y - y*y) + omega*omega*epsilon_real*x*(1-x)*y*(1-y);

	PetscScalar f(rpart, ipart);
	return f;
}



PetscScalar  exact_solution(const PetscReal x, const PetscReal y)
{
	PetscReal rpart, ipart, pi = 3.14159265359;


	rpart = sin(2*pi*x)*sin(2*pi*y);  
	ipart = x*(1-x)*y*(1-y);

	PetscScalar f(rpart, ipart);
	return f;
}



PetscScalar wave_number(const PetscReal kreal, const PetscReal kimag)
{
	//PetscReal rpart, ipart;
	//rpart = 1;
	//ipart = 1;
	PetscScalar k(kreal, kimag);
	return k;
}

int main(int argc, char **argv)
{

	PetscErrorCode ierr;

	cout << "Initializing ..." << endl;

	ierr = PetscInitialize(&argc, &argv,(char *)0, help);CHKERRQ(ierr);

	PetscInt method =  atoi(argv[1]);
	PetscBool methodSet = PETSC_FALSE;

	ierr = PetscOptionsGetInt(NULL, NULL, "-m", &method, &methodSet);
	if (method < 1 || method > 8) {
		cout << "Invalid number of the selected method: "
			<< method << ".\nExiting..." << endl;
		exit(-1);
	}

	PetscPrintf(PETSC_COMM_WORLD, "Using %s\n", GetMethodName(method));

	cout << "Setting parameters..." << endl;
	Vec b, u, exact_vector;
	Mat A;
	KSP ksp;
	PC preconditioner;
	PetscInt Nx = atoi(argv[2]), Ny = Nx, Nsys, node_idx = 0, col[5], nadj;

	char resfilename[20];
	char solfilename[20];


	Nsys = Nx*Ny; // dimesnsion of linear system = number of nodes
	PetscReal x[Nx], y[Ny], nodes[Nsys][2];
	PetscScalar value, value_epsilon, value_exact,value_error, diffpoints[5], h;


	// Set up vectors
	cout << "Setting up vectors..." << endl;
	ierr = VecCreate(PETSC_COMM_WORLD, &b); CHKERRQ(ierr);
	ierr = VecSetSizes(b, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
	ierr = VecSetType(b, VECSTANDARD); CHKERRQ(ierr);
	ierr = VecDuplicate(b, &u);

	ierr = VecCreate(PETSC_COMM_WORLD, &exact_vector); CHKERRQ(ierr);
	ierr = VecSetSizes(exact_vector, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
	ierr = VecSetType(exact_vector, VECSTANDARD); CHKERRQ(ierr);
	ierr = VecDuplicate(exact_vector, &u);



	// Set up matrix
	cout << "Setting up matrix..." << endl;
	ierr = MatCreate(PETSC_COMM_WORLD, &A); CHKERRQ(ierr);
	ierr = MatSetSizes(A,PETSC_DECIDE, PETSC_DECIDE, Nsys, Nsys); CHKERRQ(ierr);
	ierr = MatSetFromOptions(A); CHKERRQ(ierr);
	ierr = MatSetUp(A); CHKERRQ(ierr);

	// Create grid
	cout << "Constructing grid..." << endl;
	h = 1.0/(Nx - 1);
	for (int i = 0; i < Nx; i++)
		x[i] = 1.0*i/(Nx - 1);
	for (int j = 0; j < Ny; j++)
		y[j] = 1.0*j/(Ny - 1);



	// Assemble linear system ...
	cout << "Assembling system..." << endl;

	PetscScalar k;
	double omegareal = atof(argv[3]);
	double alpha = atof(argv[4]);
	cout << "Checking input parameters..." << endl;
	cout<<" Arguments: "<<argc<<endl;

	//double pi = 3.141592653589793;


	PetscScalar  resonance_frequency = 0.0;
	PetscScalar  input_frequency = omegareal;

	double b1 = 1.0; // size of the rectangular domain in x direction
	double b2 = 1.0;  // size of the rectangular domain in y direction


	double norm_input_freq;
	double norm_resonance_freq;
	double tolerance = 0.1;


	double real_part_input_freq;
	double imag_part_input_freq;
	double real_part_resonance_freq;
	double imag_part_resonance_freq;


	// compute wave length for epsilon = 1


	double wave_length = (2*M_PI)/omegareal;

	//compute number of points per wave length

	double M = wave_length/real(h);

	// accordingly to theory we should have: h omega = (2 pi)/(max(epsilon) M) < (2 pi)/ M,
	// and error in the solution to Helmholtz eq.
	// is bounded by Const. h^2 omega^3 - thus, we want to have h omega < < 1,
	// or  we check condition  (2 pi)/M < 1.
	// here max(epsilon) = 2 and thus,  we divide by  sqrt(2) - see Lecture of Ol.Runborg
	// We have following estimate for a priori error:
	double apriori_error  = (2*M_PI)/(sqrt(2)*M);


	cout<<"Number of points per wave length: "<<M<<"wave length= "<<wave_length<<" mesh size h = "<<h<<"   A priori error = "<<apriori_error<<endl;


	if(argc>2) {
		for (int i = 0; i < Nx; i++)
		{
			for (int j = 0; j < Ny; j++)
			{
				nodes[node_idx][0] = x[i];
				nodes[node_idx][1] = y[j];

				resonance_frequency = M_PI*sqrt(((i*i)/(b1*b1) + (j*j)/(b2*b2))/epsilon(x[i], y[j]));

				real_part_resonance_freq  = real(resonance_frequency);
				imag_part_resonance_freq  = imag(resonance_frequency);

				real_part_input_freq  = real(input_frequency);
				imag_part_input_freq  = imag(input_frequency);

				norm_input_freq = sqrt( real_part_input_freq*real_part_input_freq +
						imag_part_input_freq*imag_part_input_freq);	     
				norm_resonance_freq = sqrt(real_part_resonance_freq*real_part_resonance_freq + imag_part_resonance_freq*imag_part_resonance_freq);

				if ( fabs(norm_input_freq - norm_resonance_freq)  < 1.0 )
					cout<<"  norm_input_freq = "<<norm_input_freq<<"norm_resonance_freq = "<< norm_resonance_freq<<" fabs(norm_input_freq - norm_resonance_freq) = "<<fabs(norm_input_freq - norm_resonance_freq)<<endl;


				if (i > 0 && i < Nx - 1 && j > 0 && j < Ny - 1) // for interior  nodes
				{
					if ( fabs(norm_input_freq - norm_resonance_freq)  < tolerance ||  apriori_error >= 1.0 )
					{
						cout<<"*********************************************************************************"<<endl;

						if ( fabs(norm_input_freq - norm_resonance_freq)  < 1.0 )
							cout<<"  norm_input_freq = "<<norm_input_freq<<"norm_resonance_freq = "<< norm_resonance_freq<<" fabs(norm_input_freq - norm_resonance_freq) = "<<fabs(norm_input_freq - norm_resonance_freq)<<endl;

						cout<<" A priori error = "<<apriori_error<<"  for x = "<<x[i]<<"  and y = "<<y[j]<<endl;
						cout<< "Warning: this is  resonant frequency or a priori error is  >= 1. Choose another frequency !!!"<<endl;
						cout<<"*********************************************************************************"<<endl;

						// exit(1);
					}
				}

				k = omegareal*omegareal*epsilon(x[i], y[j]);
				value_epsilon =  h*h*k;

				diffpoints[0] =  -4.0 + h*h*k +   stabilization(omegareal,alpha);
				// these values corresponds to col[1] and col[2]
				diffpoints[1] = 1.0;
				diffpoints[2] = 1.0;
				// these values corresponds to col[3] and col[4]
				diffpoints[3] = 1.0;
				diffpoints[4] = 1.0;

				if (i > 0 && i < Nx - 1 && j > 0 && j < Ny - 1) // interior
				{
					// corresponds to diagonal
					col[0] = node_idx;
					// coresponds to indices (i-1,j) and (i+1,j)
					col[1] = node_idx - 1;
					col[2] = node_idx + 1;
					// corresponds to indices (i,j-1) and (i,j+1)
					col[3] = node_idx - Ny;
					col[4] = node_idx + Ny;

					nadj = 5;
					value = h*h*right_hand_side(x[i], y[j],omegareal);

				} else // on boundary
				{
					col[0] = node_idx;
					nadj   = 1;
					value  = 0.0;
				}

				value_exact = exact_solution(x[i], y[j]);

				ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); CHKERRQ(ierr);
				ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);
				ierr = VecSetValues(exact_vector, 1, &node_idx, &value_exact, INSERT_VALUES); CHKERRQ(ierr);


				node_idx++;
			}
		}

		ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
		ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

		// Residual history 
		PetscReal* hist;
		PetscInt nHist;
		PetscInt maxIt;

		// Set history
		PetscMalloc(maxIt * sizeof(PetscReal), &hist);
		hist = NULL;
		nHist = 0;
		maxIt = 1000;

		// Solve linear system
		cout << "Solving linear system ..." << endl;
		ierr = KSPCreate(PETSC_COMM_WORLD, &ksp); CHKERRQ(ierr);
		ierr = KSPSetOperators(ksp, A, A); CHKERRQ(ierr);

		// set preconditioner 
		ierr = KSPGetPC(ksp, &preconditioner); CHKERRQ(ierr);

		if (method == 1)
		{
			ierr =	PCSetType(preconditioner,PCJACOBI); CHKERRQ(ierr);
		}
		else if (method == 2)
		{
			// Gauss-Seidel preconditioner : the same as SOR when omega=1
			ierr = PCSetType(preconditioner, PCSOR); 	
			CHKERRQ(ierr);
		}
		else if (method == 3)
		{
			const PetscReal omega = 1.5;
			ierr = PCSetType(preconditioner, PCSOR); CHKERRQ(ierr);
			ierr = PCSORSetOmega(preconditioner, omega); CHKERRQ(ierr);
		}
		else if (method == 4)
		{
			ierr = PCSetType(preconditioner, PCGAMG); CHKERRQ(ierr);
		}
		else if (method == 5)
		{
			ierr = PCSetType(preconditioner, PCGASM); CHKERRQ(ierr);
		}
		else if (method == 6)
		{
			ierr = PCSetType(preconditioner, PCICC); CHKERRQ(ierr);
		}
		else if (method == 7)
		{
			ierr = PCSetType(preconditioner, PCNONE); CHKERRQ(ierr);
		}
		else if (method == 8)
		
		//ierr = KSPSetTolerances(ksp, PETSC_DEFAULT, PETSC_DEFAULT, PETSC_DEFAULT, maxIt); CHKERRQ(ierr);
		ierr = KSPSetFromOptions(ksp); CHKERRQ(ierr);

		//ierr = KSPSetResidualHistory(ksp, hist, maxIt, PETSC_TRUE); CHKERRQ(ierr);
		ierr = KSPSolve(ksp, b, u); CHKERRQ(ierr);
		//ierr = KSPGetResidualHistory(ksp, &hist, &nHist); CHKERRQ(ierr);
		
		sprintf(resfilename, "residual%d.m", Nx-1);
		FILE* residfile = fopen(resfilename, "w");
		fprintf(residfile, "nHist: %d\n", nHist);

		for (PetscInt it = 0; it < nHist; it++)
			fprintf(residfile, "%d-ksp-iteration: %f\n", it, hist[it]);
		// Print to files
		cout << "Writing to files..." << endl;
		FILE* nodefile = fopen("nodes.m", "w");
		for (int idx = 0; idx < Nsys; idx++)
			fprintf(nodefile, "%f \t %f \n", nodes[idx][0], nodes[idx][1]);
		fclose(nodefile);
		sprintf(solfilename, "values%d.m", Nx-1);
		FILE* solfile = fopen(solfilename, "w");

		FILE* errorfile = fopen("errorvalues.m", "w");
		FILE* exactfile = fopen("values_exact.m", "w");


		for (int idx = 0; idx < Nsys; idx++)
		{
			ierr = VecGetValues(u, 1, &idx, &value);
			ierr = VecGetValues(exact_vector, 1, &idx, &value_exact);

			value_error =   value_exact - value;


			fprintf(solfile, "%f \t %f \n", real(value), imag(value));
			fprintf(exactfile, "%f \t %f \n", real(value_exact), imag(value_exact));
			fprintf(errorfile, "%f \t %f \n", real(value_error), imag(value_error));


		}

		fclose(solfile);
		fclose(exactfile);
		fclose(errorfile);



		// Clean up
		ierr = VecDestroy(&b); CHKERRQ(ierr);
		ierr = VecDestroy(&exact_vector); CHKERRQ(ierr);
		ierr = VecDestroy(&u); CHKERRQ(ierr);
		ierr = MatDestroy(&A); CHKERRQ(ierr);
		ierr = KSPDestroy(&ksp); CHKERRQ(ierr);
	}
	else {cout<< "Usage: see CONFIGURATION: argv[1] argv[2] argv[3] are not defined ! "<<endl;}
	// Finalize and finish
	ierr = PetscFinalize();
	return 0;
}


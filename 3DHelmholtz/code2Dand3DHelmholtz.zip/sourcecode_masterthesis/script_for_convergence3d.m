%% the following script is equivalent to a sparse solving version of conv2new.cpp in Matlab.
%% Author: René Köhle

%% cleanup

close all
clear
clc

%% Parameter setting
omega = 10 ;

x_0=0.5;
y_0=0.5;
z_0 =0.5;
c_x= 1;
c_y=1;
c_z = 1;
u = @(x, y,z) sin(2*pi*x).*sin(2*pi*y).*sin(2*pi*z) + 1i*x.*(1 - x).*y.*(1 - y).*z.*(1-z);
%epsilon2d = @(x, y) 2*exp(-((x-x_0).*(x-x_0)/(2*c_x*c_x) +(y-y_0).*(y-y_0)/(2*c_y*c_y)));
epsilon = @(x, y,z)  2*exp(-((x-x_0).*(x-x_0)/(2*c_x.*c_x) +(y-y_0).*(y-y_0)/(2*c_y.*c_y) + (z-z_0).*(z-z_0)/(2*c_z.*c_z)));
%rhs2de = @(x,y,z) -(12*pi*pi)*sin(2*pi*x).*sin(2*pi*y).*sin(2*pi*z)+ omega*omega*epsilon2d(x,y)*(sin(2*pi*x).*sin(2*pi*y).*sin(2*pi*z)) -2i*(x.*(1-x).*y.*(1-y) + x.*(1-x).*z.*(1-z) +y.*(1-y).*z.*(1-z))+ 1i*omega*omega*epsilon2d(x,y)*x.*(1-x).*y.*(1-y).*z.*(1-z);

a=0;
b=1;


maxk = 2; % Define your maxk
color_idx = 1; % Initialize color index
error = zeros(maxk,1);
tau =zeros(maxk,1);

%% Loop over computation with varying n
for solver_index = [100]
    error = zeros(maxk,1);
    omega = solver_index;
    rhs = @(x,y,z) -(12*pi*pi)*sin(2*pi*x).*sin(2*pi*y).*sin(2*pi*z)+ omega*omega*epsilon(x,y,z)*(sin(2*pi*x).*sin(2*pi*y).*sin(2*pi*z)) -2i*(x.*(1-x).*y.*(1-y) + x.*(1-x).*z.*(1-z) +y.*(1-y).*z.*(1-z))+ 1i*omega*omega*epsilon(x,y,z)*x.*(1-x).*y.*(1-y).*z.*(1-z);

for k = 2:maxk
    
    tic
    % Set n based on 2^k + 1
    n = 2^k + 1;
    tau(k) = (b-a)/(n-1);
    Nx = n;
    Ny = n;
    Nz = n;
    
    % Other parameters
    h = 1 / (n - 1); % Define h based on n

    % Mesh grid setup
    [x_mesh, y_mesh, z_mesh] = meshgrid(linspace(0, 1, Nx), linspace(0, 1, Ny), linspace(0, 1, Nz));
    tic
    % Offset setup
    offsets = [-Nx^2, -Nx, -1, 0, 1, Nx, Nx^2];

    % Preallocate arrays
    rhs_values = zeros(Nx*Ny*Nz, 1);
    offset_values = zeros(Nx*Ny*Nz, length(offsets));

    % Loop through the mesh grid indices
    node_idx = 1;
    for i = 1:Nx
        for j = 1:Ny
            for m = 1:Nz
                % Compute k and epsilon values
                value_epsilon = -6 + h^2 * omega^2 * epsilon(x_mesh(i,j,m), y_mesh(i,j,m), z_mesh(i,j,m));
                epsilon(x_mesh(i,j,m), y_mesh(i,j,m), z_mesh(i,j,m));
                %value_epsilon2d = -6 + h^2 * omega^2 * epsilon2d(x_mesh(i,j,m), y_mesh(i,j,m));
                % Check if the node is on the boundary
                if (i == 1 || i == Nx || j == 1 || j == Ny || m == 1 || m == Nz)
                    % Store only diagonal elements on the boundary
                    offset_values(node_idx,:) = 0;
                    offset_values(node_idx, 4) = value_epsilon; % Corresponds to diagonal
                    %offset_values(node_idx, 4) = value_epsilon2d; % Corresponds to diagonal
                else
                    % Store values for interior nodes
                    offset_values(node_idx,:) = 1;
                    offset_values(node_idx, 4) = value_epsilon; % Corresponds to diagonal
                end

                % Compute right hand side value
                if (i > 1 && i < Nx && j > 1 && j < Ny && m > 1 && m < Nz) % interior
                    rhs_value = h^2 * rhs(x_mesh(i,j,m), y_mesh(i,j,m), z_mesh(i,j,m));
                    %rhs_value = h^2 * rhs2de(x_mesh(i,j,m), y_mesh(i,j,m), z_mesh(i,j,m));
                else % on boundary
                    rhs_value = 0.0;
                end

                % Store the right hand side value
                rhs_values(node_idx) = rhs_value;

                % Move to the next node
                node_idx = node_idx + 1;
            end
        end
    end

    % Create sparse matrix using spdiags
    A = spdiags(offset_values, offsets, Nx*Ny*Nz, Nx*Ny*Nz);
    toc
    % Solve for z using the sparse matrix
    tic
    z = A'\rhs_values;
    toc
    
    [Xe, Ye,Ze] = meshgrid(linspace(0, 1, Nx), linspace(0, 1, Ny),linspace(0, 1, Nz));
    ur = real(u(Xe, Ye,Ze));
    ui = imag(u(Xe, Ye,Ze));
    z_r = real(z);
    z_i = imag(z);
    Ur = reshape(z_r, Nx,Nx,Nz);
    Ui = reshape(z_i, Nx,Nx,Nz);
    format long
    norm_val  = pagenorm(Ur +Ui -ur -ui)./pagenorm(Ur+Ui);
    norm_val = norm_val(isfinite(norm_val));
    error(k) =  sum(norm_val, "omitnan")/Nx;
    %error(k) =  sum(pagenorm(pagenorm(Ur+Ui)- pagenorm(ur+ui))./pagenorm(ur+ui), "omitnan")/Nx;
    grad_error(k) =  error(k)/tau(k);
    

    % in computation of rate we observe correct rate 2.4389 only
    % for k=3, then rate computes incorrect because of round-off errors
    % since even for k=3 we have very small error
    if (k > 3)

        % computation of fractions for L_2 norm
        absolute(k) = abs(log(error(k)) - log(error(k-1)));
        % computation of fractions for H^1 norm
        grad_absolute(k) = abs(log(grad_error(k)) - log(grad_error(k-1)));

        % computation of convergence rate for L_2 norm
        rate(k) =   absolute(k)/abs(log(0.5));


        % computation of convergence rate for H^1 norm
        grad_rate(k) =   grad_absolute(k)/abs(log(0.5));
    end
   
end

%% convergence calculations
fprintf(' rate of convergence for L_2 norm %f\n', rate)

fprintf(' rate of convergence for H^1 norm %f\n', grad_rate)


% for visualization of convergence of the computed  error
comperror = zeros(maxk-1,1);
comptime = zeros(maxk-1,1);
reference = zeros(maxk-1,1);

i = 1;
for k= maxk:-1:2

    % re-assign results for presentation for L_2 norm

    reference(i) = tau(k)*tau(k);
    comptime(i) = tau(k);
    comperror(i) = error(k);

    % re-assign results for presentation for H^1 norm

    grad_reference(i) = tau(k);
    grad_comperror(i) = grad_error(k);

    i = i+1;
end
%% plots
% Plot results for each solver separately
    figure(1); hold on;
    plot(comptime, comperror,' : s', 'Linewidth', 2, 'MarkerSize', 7, 'MarkerFaceColor', 'c');
    xlabel('Mesh Size $\tau$', 'Interpreter', 'Latex');
    ylabel('$|| u - u_h ||_{L_2} / || u ||_{L_2}$', 'Interpreter', 'Latex');
    title('Convergence for $L_2$ Norm', 'Interpreter', 'Latex');
    set(gca, 'XScale', 'log', 'YScale', 'log');
    legend_entries{color_idx} = ['$\omega = $ ', num2str(solver_index)];
    
    figure(2); hold on;
    plot(comptime, grad_comperror, ' : s', 'Linewidth', 2, 'MarkerSize', 7, 'MarkerFaceColor', 'c');
    xlabel('Mesh Size $\tau$', 'Interpreter', 'Latex');
    ylabel('$|| u - u_h ||_{H_1} / || u ||_{H_1}$', 'Interpreter', 'Latex');
    title('Convergence for $H_1$ Norm', 'Interpreter', 'Latex');
    set(gca, 'XScale', 'log', 'YScale', 'log');
    legend_entries{color_idx} = ['$\omega = $ ', num2str(solver_index)];
    color_idx = color_idx +1;
end


% Plot comparison
figure(1); hold on;
plot(comptime, reference, 'k--', 'Linewidth', 2);
legend(legend_entries{:}, 'Reference $\tau^2$', 'Interpreter', 'Latex','Location', 'best');
saveas(gcf, 'solverMATLABfreq3dL2.png');

figure(2); hold on;
plot(comptime, grad_reference, 'k--', 'Linewidth', 2);
legend(legend_entries{:}, 'Reference $\tau$', 'Interpreter', 'Latex','Location', 'best');
saveas(gcf, 'solverMATLABfreq3dH1.png');

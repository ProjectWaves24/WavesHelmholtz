// to compile:
// runconv2testcopy argv[1] argv[2] argv[3] argv[4]
// Arguments:
// argv[1] - preconditioner (should be 1,2,3,4,5,6,7,8)
// argv[2] - number of discretization points in x and y and z directions
// argv[3] - frequency omega
// argv[4] - alpha of the damping term


static char help[] ="";
#include<iostream>
#include<fstream>
#include<petsc.h>
#include<petscvec.h>
#include<petscmat.h>
#include<petscksp.h>
#include<complex>
#include<ctime>

using namespace std;

char METHOD_NAMES[9][70] = {
	"invalid method",
	"Jacobi's method",
	"Gauss-Seidel method",
	"Successive Overrelaxation method (SOR)",
	"Algebraic Multigrid",
	"Additive schwarz",
	"Incomplete cholesky",
	"no preconditioner"};

char *GetMethodName(PetscInt method) {
	if (method < 0 || method > 7)
		return METHOD_NAMES[0];
	else
		return METHOD_NAMES[method];
}
PetscScalar   epsilon(const PetscReal x, const PetscReal y)
{
	PetscReal rpart, ipart;

	PetscReal x_0=0.5;
	PetscReal y_0=0.5;
	PetscReal c_x=1;
	PetscReal c_y=1;

	rpart = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));

	ipart = 0;    

	PetscScalar scalareps(rpart, ipart);
	return scalareps;

}

PetscScalar   stabilization(const PetscReal omega, const PetscReal alpha )
{
	PetscReal rpart, ipart;
	rpart = 0.0;
	ipart = omega*alpha;


	PetscScalar f(rpart, ipart);
	return f;
}

PetscScalar right_hand_side(const PetscReal x, const PetscReal y,
		const PetscReal omega)
{
	PetscReal rpart, ipart, pi = 3.14159265359;


	PetscReal x_0=0.5;
	PetscReal y_0=0.5;
	PetscReal c_x=1;
	PetscReal c_y=1;
	PetscReal epsilon_real = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));


	rpart =  -(8*pi*pi)*sin(2*pi*x)*sin(2*pi*y)+ omega*omega*epsilon_real*(sin(2*pi*x)*sin(2*pi*y));

	ipart = -2*(x - x*x + y - y*y) + omega*omega*epsilon_real*x*(1-x)*y*(1-y);

	PetscScalar f(rpart, ipart);
	return f;
}


PetscScalar  exact_solution(const PetscReal x, const PetscReal y)
{
	PetscReal rpart, ipart, pi = 3.14159265359;


	rpart = sin(2*pi*x)*sin(2*pi*y);  
	ipart = x*(1-x)*y*(1-y);

	PetscScalar f(rpart, ipart);
	return f;
}


PetscScalar wave_number(const PetscReal kreal, const PetscReal kimag)
{
	//PetscReal rpart, ipart;
	//rpart = 1;
	//ipart = 1;
	PetscScalar k(kreal, kimag);
	return k;
}

// Function to print a PETSc vector
void printVec(Vec vec, const char *name) {
	PetscPrintf(PETSC_COMM_WORLD, "%s:\n", name);
	VecView(vec, PETSC_VIEWER_STDOUT_WORLD);
	PetscPrintf(PETSC_COMM_WORLD, "\n");
}

// Function to print a PETSc matrix
void printMat(Mat mat, const char *name) {
	PetscPrintf(PETSC_COMM_WORLD, "%s:\n", name);
	MatView(mat, PETSC_VIEWER_STDOUT_WORLD);
	PetscPrintf(PETSC_COMM_WORLD, "\n");
}

int main(int argc, char **argv)
{

	PetscErrorCode ierr;

	cout << "Initializing ..." << endl;
	// PetscInitialize(&argc, &argv, NULL, NULL);

	ierr = PetscInitialize(&argc, &argv,(char *)0, help);CHKERRQ(ierr);

	PetscInt method =  atoi(argv[1]);
	PetscBool methodSet = PETSC_FALSE;

	ierr = PetscOptionsGetInt(NULL, NULL, "-m", &method, &methodSet);
	if (method < 1 || method > 8) {
		cout << "Invalid number of the selected method: "
			<< method << ".\nExiting..." << endl;
		exit(-1);
	}

	PetscPrintf(PETSC_COMM_WORLD, "Using %s\n", GetMethodName(method));

	cout << "Setting parameters..." << endl;
	Vec b, u, exact_vector;
	Mat A;
	KSP ksp;
	PC preconditioner;
	PetscInt Nx = atoi(argv[2]), Ny = Nx, Nsys;

	char resfilename[20];
	char solfilename[20];


	Nsys = Nx*Ny; // dimesnsion of linear system = number of nodes
	PetscReal x[Nx], y[Ny], nodes[Nsys][2];
	PetscScalar value, value_epsilon, value_exact,value_error, h;
	char exactsolfilename[20];

	// Set up vectors
	cout << "Setting up vectors..." << endl;

	ierr = VecCreate(PETSC_COMM_WORLD, &exact_vector); CHKERRQ(ierr);
	ierr = VecSetSizes(exact_vector, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
	ierr = VecSetType(exact_vector, VECSTANDARD); CHKERRQ(ierr);


	PetscInt node_idx = 0;
	ierr = MatCreateSeqAIJ(PETSC_COMM_SELF, Nx * Ny , Nx * Ny , 5, NULL, &A);
	ierr = VecCreateSeq(PETSC_COMM_SELF, Nx * Ny , &b);
	ierr = VecDuplicate(b, &u);
	ierr = VecDuplicate(exact_vector, &u);
	// Set up matrix
	cout << "Setting up matrix..." << endl;
	

	// Create grid
	cout << "Constructing grid..." << endl;
	h = 1.0/(Nx - 1);
	for (int i = 0; i < Nx; i++)
		x[i] = 1.0*i/(Nx - 1);
	for (int j = 0; j < Ny; j++)
		y[j] = 1.0*j/(Ny - 1);



	// Assemble linear system ...
	cout << "Assembling system..." << endl;

	PetscScalar k;
	double omega = atof(argv[3]);
	double alpha = atof(argv[4]);

	cout << "Checking input parameters..." << endl;
	cout<<" Arguments: "<<argc<<endl;

	double wave_length = (2*M_PI)/omega;

	//compute number of points per wave length

	double M = wave_length/real(h);

	// accordingly to theory we should have: h omega = (2 pi)/(max(epsilon) M) < (2 pi)/ M,
	// and error in the solution to Helmholtz eq.
	// is bounded by Const. h^2 omega^3 - thus, we want to have h omega < < 1,
	// or  we check condition  (2 pi)/M < 1.
	// here max(epsilon) = 2 and thus,  we divide by  sqrt(2) - see Lecture of Ol.Runborg
	// We have following estimate for a priori error:
	double apriori_error  = (2*M_PI)/(sqrt(2)*M);


	cout<<"Number of points per wave length: "<<M<<"wave length= "<<wave_length<<" mesh size h = "<<h<<"   A priori error = "<<apriori_error<<endl;


	if(argc>2) {


		// Preallocate arrays
		//PetscScalar *rhs_values = new PetscScalar[Nx*Ny];

		// Assemble linear system ...
		cout << "Assembling system..." << endl;


		for (PetscInt i = 0; i < Nx; ++i) {
			for (PetscInt j = 0; j < Ny; ++j) {
				PetscScalar value_epsilon = -4.0 + h * h * omega * omega * epsilon(x[i], y[j]) + stabilization(omega,alpha);

				// Check if the node is on the boundary
				if (i == 0 || i == Nx - 1 || j == 0 || j == Ny - 1 ) {
					// Store only diagonal elements on the boundary
					PetscScalar diag_value = value_epsilon;
					MatSetValue(A, node_idx, node_idx, diag_value, INSERT_VALUES);
				} else {
					// Store values for interior nodes
					PetscScalar values[] = {1, 1, 1, 1, 1,   value_epsilon};
					PetscInt cols[] = { node_idx - Nx, node_idx - 1, node_idx,
						node_idx + 1, node_idx + Nx,  node_idx};
					MatSetValues(A, 1, &node_idx, 6, cols, values, INSERT_VALUES);
				}

				// Compute right hand side value
				PetscScalar rhs_value = 0.0;
				if (0 < i && i < Nx - 1 && 0 < j && j < Ny - 1 ) {
					// interior
					rhs_value = h * h * right_hand_side(x[i], y[j], omega);
				}
				PetscScalar value_exact = exact_solution(x[i], y[j]);
				ierr = VecSetValue(exact_vector, node_idx, value_exact, INSERT_VALUES); CHKERRQ(ierr);

				// Store the right hand side value
				VecSetValue(b, node_idx, rhs_value, INSERT_VALUES);

				// Move to the next node
				node_idx++;

			}
		}

		// Assemble the matrix and view it

		ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
		ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

		// Assemble the vectors
		ierr = VecAssemblyBegin(b); CHKERRQ(ierr);
		ierr = VecAssemblyEnd(b); CHKERRQ(ierr);
		
		// Residual history 
		PetscReal* hist;
		PetscInt nHist;
		PetscInt maxIt;

		// Set history
		PetscMalloc(maxIt * sizeof(PetscReal), &hist);
		hist = NULL;
		nHist = 0;
		maxIt = 1000;

		// Solve linear system
		cout << "Solving linear system ..." << endl;
		
		ierr = KSPCreate(PETSC_COMM_WORLD, &ksp); CHKERRQ(ierr);
	
		ierr = KSPSetOperators(ksp, A, A); CHKERRQ(ierr);
		// set preconditioner 
		ierr = KSPGetPC(ksp, &preconditioner); CHKERRQ(ierr);

		if (method == 1)
		{
			ierr =	PCSetType(preconditioner,PCJACOBI); CHKERRQ(ierr);
		}
		else if (method == 2)
		{
			// Gauss-Seidel preconditioner : the same as SOR when omega=1
			ierr = PCSetType(preconditioner, PCSOR); 	
			CHKERRQ(ierr);
		}
		else if (method == 3)
		{
			const PetscReal omega = 1.5;
			ierr = PCSetType(preconditioner, PCSOR); CHKERRQ(ierr);
			ierr = PCSORSetOmega(preconditioner, omega); CHKERRQ(ierr);
		}
		else if (method == 4)
		{
			ierr = PCSetType(preconditioner, PCGAMG); CHKERRQ(ierr);
		}
		else if (method == 5)
		{
			ierr = PCSetType(preconditioner, PCGASM); CHKERRQ(ierr);
		}
		else if (method == 6)
		{
			ierr = PCSetType(preconditioner, PCICC); CHKERRQ(ierr);
		}
		else if (method == 7)
		{
			ierr = PCSetType(preconditioner, PCNONE); CHKERRQ(ierr);
		}
		ierr = KSPSetFromOptions(ksp); CHKERRQ(ierr);
		ierr = KSPSolve(ksp, b, u); CHKERRQ(ierr);
		ierr = KSPDestroy(&ksp); CHKERRQ(ierr);


		sprintf(resfilename, "residual%d.m", Nx-1);
		FILE* residfile = fopen(resfilename, "w");
		fprintf(residfile, "nHist: %d\n", nHist);

		for (PetscInt it = 0; it < nHist; it++)
			fprintf(residfile, "%d-ksp-iteration: %f\n", it, hist[it]);
		// Print to files
		cout << "Writing to files..." << endl;
		FILE* nodefile = fopen("nodes.m", "w");
		for (int idx = 0; idx < Nsys; idx++)
			fprintf(nodefile, "%f \t %f \n", nodes[idx][0], nodes[idx][1]);
		fclose(nodefile);
		sprintf(solfilename, "values%d.m", Nx-1);
		FILE* solfile = fopen(solfilename, "w");

		//FILE* errorfile = fopen("errorvalues.m", "w");
		sprintf(exactsolfilename, "values_exact%d.m", Nx-1);
		FILE* exactfile = fopen(exactsolfilename, "w");


		for (int idx = 0; idx < Nsys; idx++)
		{
			ierr = VecGetValues(u, 1, &idx, &value);
			ierr = VecGetValues(exact_vector, 1, &idx, &value_exact);

			value_error =   value_exact - value;


			fprintf(solfile, "%f \t %f \n", real(value), imag(value));
			fprintf(exactfile, "%f \t %f \n", real(value_exact), imag(value_exact));


		}

		fclose(solfile);
		fclose(exactfile);
		
		// Clean up
		ierr = VecDestroy(&b); CHKERRQ(ierr);
		ierr = VecDestroy(&u); CHKERRQ(ierr);
		ierr = MatDestroy(&A); CHKERRQ(ierr);
		ierr = KSPDestroy(&ksp); CHKERRQ(ierr);
	}
	else {cout<< "Usage: see CONFIGURATION: argv[1] argv[2] argv[3] argv[4] are not defined ! "<<endl;}
	// Finalize and finish
	ierr = PetscFinalize();
	return 0;
}



% Define parameters
x_0 = 0.5;
y_0 = 0.5;
z_0 = 0.5;
c_x = 0.1;
c_y = 0.1;
c_z = 0.1;
u = @(x, y, z) sin(2*pi*x).*sin(2*pi*y).*sin(2*pi*z) + 1i*x.*(1 - x).*y.*(1 - y).*z.*(1 - z);
epsilon = @(x, y, z) 2*exp(-((x-x_0).*(x-x_0)/(2*c_x.*c_x) +(y-y_0).*(y-y_0)/(2*c_y.*c_y) + (z-z_0).*(z-z_0)/(2*c_z.*c_z)));
% Load nodes and values
nodes = load('nodes.m');
values = load('values20.m');

% Reshape nodes and values
n = round(size(nodes, 1)^(1/3));
[X,Y, Z] = meshgrid(linspace(0, 1, n), linspace(0, 1, n), linspace(0, 1, n));
Ur1 = reshape(values(:, 1), [n, n, n]);
Ui1 = reshape(values(:, 2), [n, n, n]);

% Compute modulus of the computed solution
modUh = sqrt(values(:, 1).^2 + values(:, 2).^2);
modUh = reshape(modUh, [n, n, n]);

% Define mesh for plotting exact solution
meshsize = 65;
[Xe, Ye, Ze] = meshgrid(linspace(0, 1, meshsize), linspace(0, 1, meshsize), linspace(0, 1, meshsize));
ur = real(u(Xe, Ye, Ze));
ui = imag(u(Xe, Ye, Ze));

% Compute modulus of the exact solution
modU = sqrt(ur.^2 + ui.^2);

% Compute epsilon for exact solution
Eps = epsilon(Xe, Ye, Ze);

% Plotting
ig = figure('Position', [100, 100, 1200, 600]);
z_index = 2;
% 3D surface plot of computed solution
ax1 = subplot(1, 2, 1);
surf(X(:, :, z_index), Y(:, :, z_index), Ur1(:, :, z_index), 'EdgeColor', 'none');
title('Real part of u_h, computed');
xlabel('X');
ylabel('Y');
zlabel('Real part of u_h');
colorbar;

% 3D surface plot of exact solution
ax2 = subplot(1, 2, 2);
surf(Xe(:, :, z_index), Ye(:, :, z_index), ur(:, :, z_index), 'EdgeColor', 'none');
title('Real part of u, exact');
xlabel('X');
ylabel('Y');
zlabel('Real part of u');
colorbar;

% Plot a slice in the z-direction for computed and exact solutions
slice_index = 3;  % Choose the index for the z-slice
fig2 = figure('Position', [100, 100, 1200, 600]);

% Computed solution
slice_Uh = modUh(:, :, slice_index);
subplot(1, 2, 1);
contourf(X(:, :, slice_index), Y(:, :, slice_index), slice_Uh, 'EdgeColor', 'none');
title(['|u_h| slice at z=', num2str(Z(1, 1, slice_index))]);
colorbar;

% Exact solution
slice_U = modU(:, :, slice_index);
subplot(1, 2, 2);
contourf(Xe(:, :, slice_index), Ye(:, :, slice_index), slice_U, 'EdgeColor', 'none');
title(['|u| slice at z=', num2str(Ze(1, 1, slice_index))]);
colorbar;

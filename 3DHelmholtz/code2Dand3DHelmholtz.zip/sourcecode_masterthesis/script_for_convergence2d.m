%% the following script is equivalent to a sparse solving version of conv2testcopy.cpp in Matlab.
%% Author: René Köhle

clear
close all

tic

x_0=0.5;
y_0=0.5;
c_x= 0.1;
c_y=0.1;
u = @(x, y) sin(2*pi*x).*sin(2*pi*y) + 1i*x.*(1 - x).*y.*(1 - y);
epsilon = @(x, y) 2*exp(-((x-x_0).*(x-x_0)/(2*c_x*c_x) +(y-y_0).*(y-y_0)/(2*c_y*c_y)));
%rhs = @(x,y,epsilon_r) -(8*pi*pi)*sin(2*pi*x).*sin(2*pi*y)+ omega*omega*epsilon_r.*sin(2*pi*x).*sin(2*pi*y) -2i*(x - x.*x + y - y.*y) + 1i*omega*omega*epsilon_r.*x.*(1-x).*y.*(1-y);
a=0;
b=1;
% Define parameters
maxk = 9; % Define your maxk

color_idx = 1; % Initialize color index
error = zeros(maxk,1);
tau =zeros(maxk,1);
% Loop over computation with varying 
for solver_index = [10]
    error = zeros(maxk,1);
    omega = solver_index;
    rhs = @(x,y) -(8*pi*pi)*sin(2*pi*x).*sin(2*pi*y)+ omega*omega*epsilon(x,y).*sin(2*pi*x).*sin(2*pi*y) -2i*(x - x.*x + y - y.*y) + 1i*omega*omega*epsilon(x,y).*x.*(1-x).*y.*(1-y);
    for k = 2:maxk
        tic
        % Set n based on 2^k + 1
        n = 2^k + 1;
        tau(k) = (b-a)/(n-1);
        Nx = n;
        Ny = n;
        
        h = 1.0/(Nx - 1);
        
        x = linspace(0, 1, Nx);
        y = linspace(0, 1, Ny);
        
        % Initialize matrix
        matrix_size = Nx * Ny;
        
        % Initialize node_idx
        node_idx = 1;
        [x_mesh, y_mesh] = meshgrid(linspace(0, 1, Nx), linspace(0, 1, Ny));
        offsets = [-Nx, -1, 1, Nx];
        offset_values = ones(Nx*Ny, length(offsets));% Initialize rhs_values and k_values
        rhs_values = zeros(Nx*Ny, 1);
        k_values = zeros(Nx*Ny, 1);
        % Loop over grid points
        for i = 1:Nx
            for j = 1:Ny
                if (i > 1 && i < Nx && j > 1 && j < Ny) % interior
                    epsilon_val = epsilon(x_mesh(i, j), y_mesh(i, j));
                    k_values(node_idx) = -4 + h^2 * omega^2 * epsilon_val;
                    rhs_values(node_idx) = h^2 * rhs(x_mesh(i, j), y_mesh(i, j));
                else % on boundary
                    epsilon_val = epsilon(x_mesh(i, j), y_mesh(i, j));
                    k_values(node_idx) = -4 + h^2 * omega^2 * epsilon_val; % Store diagonal element
                    rhs_values(node_idx) = 0.0;
                    % Modify offset_values for boundary nodes
                    for offset_idx = 1:length(offsets)
                        if (i == 1 && offsets(offset_idx) == -1) || ...
                           (i == Nx && offsets(offset_idx) == 1) || ...
                           (j == 1 && offsets(offset_idx) == -Nx) || ...
                           (j == Ny && offsets(offset_idx) == Nx)
                            offset_values(node_idx, offset_idx) = 0; % Remove off-diagonal elements
                        end
                    end
                end
                node_idx = node_idx + 1;
            end
        end
        
        
        boundary_offset = (abs(offsets) == 1) & (abs(offsets) == Nx); % Combine offsets
        
        % Apply the combined offset to the boundary nodes
        boundary_indices = [1:Nx, (Ny-1)*Nx+1:Nx*Ny, 1:Nx:Nx*(Ny-1)+1, Nx:Nx:Nx*Ny];
        offset_values(boundary_indices, :) = offset_values(boundary_indices, :) .* boundary_offset;
       
        
        % Create sparse matrix using spdiags
        A = spdiags(offset_values, offsets, Nx*Ny, Nx*Ny) + spdiags(k_values, 0, Nx*Ny, Nx*Ny);
        
        rhs_values(1:Nx+1) =0;
        rhs_values(Nx^2-Nx:Nx^2) =0;
        toc
    
        tic
        z = A'\rhs_values;
        toc
        [Xe, Ye] = meshgrid(linspace(0, 1, Nx), linspace(0, 1, Ny));
        ur = real(u(Xe, Ye));
        ui = imag(u(Xe, Ye));
        z_r = real(z);
        z_i = imag(z);
        Ur = reshape(z_r, Nx,Nx);
        Ui = reshape(z_i, Nx,Nx);
        format long
        error(k) = norm(norm(Ur+Ui)- norm(ur+ui))/norm(ur+ui);
        
            % error for H^1 norm
        
            grad_error(k) =  error(k)/tau(k);
        
        
            % in computation of rate we observe correct rate 2.4389 only
            % for k=3, then rate computes incorrect because of round-off errors
            % since even for k=3 we have very small error
            if (k > 3)
    
                % computation of fractions for L_2 norm
                absolute(k) = abs(log(error(k)) - log(error(k-1)));
                % computation of fractions for H^1 norm
                grad_absolute(k) = abs(log(grad_error(k)) - log(grad_error(k-1)));
        
                % computation of convergence rate for L_2 norm
                rate(k) =   absolute(k)/abs(log(0.5));
        
        
                % computation of convergence rate for H^1 norm
                grad_rate(k) =   grad_absolute(k)/abs(log(0.5));
            end
           
    end
    
    fprintf(' rate of convergence for L_2 norm %f\n', rate)
    
    fprintf(' rate of convergence for H^1 norm %f\n', grad_rate)
    
    
    % for visualization of convergence of the computed  error
    comperror = zeros(maxk-1,1);
    comptime = zeros(maxk-1,1);
    reference = zeros(maxk-1,1);
    
    i = 1;
    for k= maxk:-1:2
    
        % re-assign results for presentation for L_2 norm
    
        reference(i) = tau(k)*tau(k);
        comptime(i) = tau(k);
        comperror(i) = error(k);
    
        % re-assign results for presentation for H^1 norm
    
        grad_reference(i) = tau(k);
        grad_comperror(i) = grad_error(k);
    
        i = i+1;
    end
 % Plot results for each solver separately
    figure(1); hold on;
    plot(comptime, comperror, ' : s', 'Linewidth', 2, 'MarkerSize', 7, 'MarkerFaceColor', 'c');
    xlabel('Mesh Size $\tau$', 'Interpreter', 'Latex');
    ylabel('$|| u - u_h ||_{L_2} / || u ||_{L_2}$', 'Interpreter', 'Latex');
    title('Convergence for $L_2$ Norm', 'Interpreter', 'Latex');
    set(gca, 'XScale', 'log', 'YScale', 'log');
    legend_entries{color_idx} = ['$\omega = $', num2str(solver_index)];
    
    figure(2); hold on;
    plot(comptime, grad_comperror, ' : s', 'Linewidth', 2, 'MarkerSize', 7, 'MarkerFaceColor', 'c');
    xlabel('Mesh Size $\tau$', 'Interpreter', 'Latex');
    ylabel('$|| u - u_h ||_{H_1} / || u ||_{H_1}$', 'Interpreter', 'Latex');
    title('Convergence for $H_1$ Norm', 'Interpreter', 'Latex');
    set(gca, 'XScale', 'log', 'YScale', 'log');
    legend_entries{color_idx} = ['$\omega = $', num2str(solver_index)];
    color_idx = color_idx +1;
end
%%
% Plot comparison
figure(1); hold on;
plot(comptime, reference, 'k--', 'Linewidth', 2);
legend(legend_entries{:}, 'Reference $\tau^2$', 'Interpreter', 'Latex','Location', 'best');
saveas(gcf, 'solverMATLABfreq2dL2.png');

figure(2); hold on;
plot(comptime, grad_reference, 'k--', 'Linewidth', 2);
legend(legend_entries{:}, 'Reference $\tau$', 'Interpreter', 'Latex','Location', 'best');
saveas(gcf, 'solverMATLABfreq2dH1.png');







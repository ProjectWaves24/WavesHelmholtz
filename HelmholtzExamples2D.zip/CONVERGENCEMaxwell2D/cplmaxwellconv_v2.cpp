// to compile:
// runmaxwellv2 argv[1] argv[2]
// Arguments:
// argv[1] - preconditioner (should be 1,2 or 3)
// argv[2] - number of discretization points in x and y directions

static char help[] ="";
#include<iostream>
#include<fstream>
#include<petsc.h>
#include<petscvec.h>
#include<petscmat.h>
#include<petscksp.h>
#include<complex>

using namespace std;

char METHOD_NAMES[8][70] = {
    "invalid method",
    "Jacobi's method",
    "Gauss-Seidel method",
    "Successive Overrelaxation method (SOR)"};

char *GetMethodName(PetscInt method) {
    if (method < 0 || method > 3)
        return METHOD_NAMES[0];
    else
        return METHOD_NAMES[method];
}


PetscScalar   epsilon(const PetscReal x, const PetscReal y)
{
  PetscReal rpart, ipart;
  
PetscReal x_0=0.5;
PetscReal y_0=0.5;
PetscReal c_x=1;
PetscReal c_y=1;

 rpart = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));

  ipart = 0;    

  PetscScalar scalareps(rpart, ipart);
  return scalareps;
  
}


PetscScalar right_hand_side(const PetscReal x, const PetscReal y,
			    const PetscReal omega)
{
  PetscReal rpart, ipart, pi = 3.14159265359;


  PetscReal x_0=0.5;
  PetscReal y_0=0.5;
  PetscReal c_x=1;
  PetscReal c_y=1;
  PetscReal epsilon_real = 2*exp(-((x-x_0)*(x-x_0)/(2*c_x*c_x) +(y-y_0)*(y-y_0)/(2*c_y*c_y)));
 
 
  rpart =  -(8*pi*pi)*sin(2*pi*x)*sin(2*pi*y)+ omega*omega*epsilon_real*(sin(2*pi*x)*sin(2*pi*y));
  
  ipart = -2*(x - x*x + y - y*y) + omega*omega*epsilon_real*x*(1-x)*y*(1-y);
    
  PetscScalar f(rpart, ipart);
  return f;
}



PetscScalar  exact_solution(const PetscReal x, const PetscReal y)
{
  PetscReal rpart, ipart, pi = 3.14159265359;

 
  rpart = sin(2*pi*x)*sin(2*pi*y);  
  ipart = x*(1-x)*y*(1-y);
    
  PetscScalar f(rpart, ipart);
  return f;
}



PetscScalar wave_number(const PetscReal kreal, const PetscReal kimag)
{
  //PetscReal rpart, ipart;
    //rpart = 1;
    //ipart = 1;
    PetscScalar k(kreal, kimag);
    return k;
}

int main(int argc, char **argv)
{
  PetscErrorCode ierr;
  
  cout << "Initializing ..." << endl;
  // PetscInitialize(&argc, &argv, NULL, NULL);

 ierr = PetscInitialize(&argc, &argv,(char *)0, help);CHKERRQ(ierr);
  
  PetscInt method =  atoi(argv[1]);
  PetscBool methodSet = PETSC_FALSE;
 
ierr = PetscOptionsGetInt(NULL, NULL, "-m", &method, &methodSet);
    if (method < 1 || method > 7) {
        cout << "Invalid number of the selected method: "
	     << method << ".\nExiting..." << endl;
        exit(-1);
    }

        PetscPrintf(PETSC_COMM_WORLD, "Using %s\n", GetMethodName(method));
  
  cout << "Setting parameters..." << endl;
  Vec b, u, exact_vector;
  Mat A;
  KSP ksp;
  PC preconditioner;
  PetscInt Nx = atoi(argv[2]), Ny = Nx, Nsys, node_idx = 0, col[5], nadj;


  
  Nsys = Nx*Ny; // dimesnsion of linear system = number of nodes
  PetscReal x[Nx], y[Ny], nodes[Nsys][2];
  PetscScalar value, value_epsilon, value_exact,value_error, diffpoints[5], h;
 
  
  // Set up vectors
  cout << "Setting up vectors..." << endl;
  ierr = VecCreate(PETSC_COMM_WORLD, &b); CHKERRQ(ierr);
  ierr = VecSetSizes(b, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
  ierr = VecSetType(b, VECSTANDARD); CHKERRQ(ierr);
  ierr = VecDuplicate(b, &u);
 
  ierr = VecCreate(PETSC_COMM_WORLD, &exact_vector); CHKERRQ(ierr);
  ierr = VecSetSizes(exact_vector, PETSC_DECIDE, Nsys); CHKERRQ(ierr);
  ierr = VecSetType(exact_vector, VECSTANDARD); CHKERRQ(ierr);
  ierr = VecDuplicate(exact_vector, &u);
 
  
  
  // Set up matrix
  cout << "Setting up matrix..." << endl;
  ierr = MatCreate(PETSC_COMM_WORLD, &A); CHKERRQ(ierr);
  ierr = MatSetSizes(A,PETSC_DECIDE, PETSC_DECIDE, Nsys, Nsys); CHKERRQ(ierr);
  ierr = MatSetFromOptions(A); CHKERRQ(ierr);
  ierr = MatSetUp(A); CHKERRQ(ierr);

  // Create grid
  cout << "Constructing grid..." << endl;
  h = 1.0/(Nx - 1);
  for (int i = 0; i < Nx; i++)
    x[i] = 1.0*i/(Nx - 1);
  for (int j = 0; j < Ny; j++)
    y[j] = 1.0*j/(Ny - 1);


  
  // Assemble linear system ...
  cout << "Assembling system..." << endl;

  PetscScalar k;
  double omegareal=10;
  
  
  for (int i = 0; i < Nx; i++)
    {
      for (int j = 0; j < Ny; j++)
	{
	  nodes[node_idx][0] = x[i];
	  nodes[node_idx][1] = y[j];

	   k = omegareal*omegareal*epsilon(x[i], y[j]);
	   value_epsilon =  h*h*k;
	 
	diffpoints[0] =  -4.0 + h*h*k;
	//diffpoints[0] =  -4.0;
        diffpoints[1] = 1.0;
        diffpoints[2] = 1.0;
        diffpoints[3] = 1.0;
        diffpoints[4] = 1.0;

	  if (i > 0 && i < Nx - 1 && j > 0 && j < Ny - 1) // interior
	  {
            col[0] = node_idx;
            col[1] = node_idx - 1;
            col[2] = node_idx + 1;
            col[3] = node_idx - Ny;
            col[4] = node_idx + Ny;
            
            nadj = 5;
            value = h*h*right_hand_side(x[i], y[j],omegareal);

	   
	       } else // on boundary
	    {
	      col[0] = node_idx;
	      nadj   = 1;
	      value  = 0.0;
	    }
	  
	   value_exact = exact_solution(x[i], y[j]);
	    
	  ierr = MatSetValues(A, 1, &node_idx, nadj, col, diffpoints, INSERT_VALUES); CHKERRQ(ierr);
	  ierr = VecSetValues(b, 1, &node_idx, &value, INSERT_VALUES); CHKERRQ(ierr);
          ierr = VecSetValues(exact_vector, 1, &node_idx, &value_exact, INSERT_VALUES); CHKERRQ(ierr);
	  
	  	   
	  node_idx++;
	}
    }
  ierr = MatAssemblyBegin(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);
  ierr = MatAssemblyEnd(A, MAT_FINAL_ASSEMBLY); CHKERRQ(ierr);

  // Solve linear system
  cout << "Solving linear system ..." << endl;
  ierr = KSPCreate(PETSC_COMM_WORLD, &ksp); CHKERRQ(ierr);
  ierr = KSPSetOperators(ksp, A, A); CHKERRQ(ierr);

  // set preconditioner 
   ierr = KSPGetPC(ksp, &preconditioner); CHKERRQ(ierr);
   
    if (method == 1)
      {
 ierr =	PCSetType(preconditioner,PCJACOBI); CHKERRQ(ierr);
      }
    else if (method == 2)
      {
	// Gauss-Seidel preconditioner : the same as SOR when omega=1
 ierr = PCSetType(preconditioner, PCSOR); 	
  CHKERRQ(ierr);
      }
else if (method == 3)
  {
    const PetscReal omega = 1.5;
    ierr = PCSetType(preconditioner, PCSOR); CHKERRQ(ierr);
    ierr = PCSORSetOmega(preconditioner, omega); CHKERRQ(ierr);
  }
 
    
  ierr = KSPSetFromOptions(ksp); CHKERRQ(ierr);
  ierr = KSPSolve(ksp, b, u); CHKERRQ(ierr);

   // Print to files
  cout << "Writing to files..." << endl;
  FILE* nodefile = fopen("nodes.m", "w");
  for (int idx = 0; idx < Nsys; idx++)
    fprintf(nodefile, "%f \t %f \n", nodes[idx][0], nodes[idx][1]);
  fclose(nodefile);
  FILE* solfile = fopen("values.m", "w");

   FILE* errorfile = fopen("errorvalues.m", "w");
  
    
  for (int idx = 0; idx < Nsys; idx++)
    {
      ierr = VecGetValues(u, 1, &idx, &value);
      ierr = VecGetValues(exact_vector, 1, &idx, &value_exact);

	   value_error =   value_exact - value;
	    
      
      fprintf(solfile, "%f \t %f \n", real(value), imag(value));
      fprintf(errorfile, "%f \t %f \n", real(value_error), imag(value_error));

      
    }

  fclose(solfile);


  
  // Clean up
  ierr = VecDestroy(&b); CHKERRQ(ierr);
   ierr = VecDestroy(&exact_vector); CHKERRQ(ierr);
  ierr = VecDestroy(&u); CHKERRQ(ierr);
  ierr = MatDestroy(&A); CHKERRQ(ierr);
  ierr = KSPDestroy(&ksp); CHKERRQ(ierr);

  // Finalize and finish
  ierr = PetscFinalize();
  return 0;
}


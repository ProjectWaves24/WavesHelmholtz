close all;
clear
set(gca, 'YScale', 'log');
set(gca, 'XScale', 'log');


% number of nodes for meshes:
%  l= 6; h= 0.015625 = 1/2^6  ---> nx = ny = 1/h +1 = 65
%  l= 5; h =    0.03125 = 1/2^5 ---> nx = ny = 1/h + 1 = 33
%  l= 4; h =  0.0625 = 1/2^4   ---> nx = ny = 1/h + 1 = 17
%  l= 3 ; h = 0.125 = 1/(2^3) ----> nx = ny = 1/h + 1 = 9
  
h=[0.015625, 0.03125, 0.0625, 0.125];
%h=[0.03125, 0.0625, 0.125];


%h=[0.015625, 0.03125, 0.0625, 0.125,0.25,0.5];
%h=[0.03125, 0.0625, 0.125,0.25,0.5];

nno = [1089,289,81,25];
%nno = [289,81,25];

% nno for  6 meshes
%nno = [4225,1089,289,81,25,9];

% exact solution
u = @(x, y) sin(2*pi*x).*sin(2*pi*y) + 1i*x.*(1 - x).*y.*(1 - y);




% ***************  compute L_2 norms for the  paper on Hybrid FEM/FDM for Maxwell's eq. with sigma =0
% here data is  after Laplace transform
% here is abs.  values of the computed solution
load /chalmers/users/larisa/PAPERS/AsadzadehBeilina/FEMFDMsigma0/MatlabL2Norm/6/sampcompabsE60.125.m;
load /chalmers/users/larisa/PAPERS/AsadzadehBeilina/FEMFDMsigma0/MatlabL2Norm/6/sampcompabsE60.0625.m;
load /chalmers/users/larisa/PAPERS/AsadzadehBeilina/FEMFDMsigma0/MatlabL2Norm/6/sampcompabsE60.03125.m;
load /chalmers/users/larisa/PAPERS/AsadzadehBeilina/FEMFDMsigma0/MatlabL2Norm/6/sampcompabsE60.015625.m;

%     here data is computed exact on the very fine mesh                                                                             
load /chalmers/users/larisa/PAPERS/AsadzadehBeilina/FEMFDMsigma0/MatlabL2Norm/6/sampexcompabsE60.125.m;
load /chalmers/users/larisa/PAPERS/AsadzadehBeilina/FEMFDMsigma0/MatlabL2Norm/6/sampexcompabsE60.0625.m;
load /chalmers/users/larisa/PAPERS/AsadzadehBeilina/FEMFDMsigma0/MatlabL2Norm/6/sampexcompabsE60.03125.m;
load /chalmers/users/larisa/PAPERS/AsadzadehBeilina/FEMFDMsigma0/MatlabL2Norm/6/sampexcompabsE60.015625.m;

%compute norms of the computed solutions
maxm60125 =  norm(sampcompabsE60_125);
maxm60625 =  norm(sampcompabsE60_0625);
maxm603125 =  norm(sampcompabsE60_03125);
maxm6015625 =  norm(sampcompabsE60_015625);

comper1 = maxm6015625/maxm603125;
comper2 = maxm603125/maxm60625;
comper3 = maxm60625/maxm60125;

fprintf(' maxm6015625/maxm603125= %f\n', comper1)
fprintf(' maxm603125/maxm60625= %f\n', comper2)
fprintf('maxm60625/maxm60125 = %f\n', comper3)
normcomp = [maxm6015625,maxm603125,maxm60625,maxm60125];

fprintf('Norms for the computed solution = %f\n', normcomp)

% compute norms of the exact solutions
exactmaxm60125 =  norm(sampexcompabsE60_125);
exactmaxm60625 =  norm(sampexcompabsE60_0625);
exactmaxm603125 =  norm(sampexcompabsE60_03125);
exactmaxm6015625 =  norm(sampexcompabsE60_015625);

normexact =[exactmaxm6015625,exactmaxm603125,exactmaxm60625,exactmaxm60125];

fprintf('Norms for the exact solution = %f\n', normexact)
er1 = exactmaxm6015625/exactmaxm603125;
er2 = exactmaxm603125/exactmaxm60625;
er3 = exactmaxm60625/exactmaxm60125;
fprintf(' exactmaxm6015625/exactmaxm603125 = %f\n', er1)
fprintf(' exactmaxm603125/exactmaxm60625 = %f\n', er2)
fprintf(' exactmaxm60625/exactmaxm60125= %f\n', er3)


% Compute L_2 norm  for 4 meshes

% m6= [h(1)*h(1)*maxm6015625, h(2)*h(2)*maxm603125,h(3)*h(3)*maxm60625,h(4)*h(4)*maxm60125];

% m6= [h(1)*h(1)*maxm603125,h(2)*h(2)*maxm60625,h(3)*h(3)*maxm60125];


% Compute L_2 norm  for 3 meshes
%m6= [abs(maxm603125 - exactmaxm603125)/exactmaxm603125,abs(maxm60625 - exactmaxm60625)/exactmaxm60625,abs(maxm60125  - exactmaxm60125)/exactmaxm60125];

% Compute grad L_2 norm  for 3 meshes
%gradm6 =   [m6(1)/h(1), m6(2)/h(2),m6(3)/h(3)];

% Compute  relative L_2 norm  for 4 meshes

m6 = [abs(maxm6015625 - exactmaxm6015625)/exactmaxm6015625, abs(maxm603125 - exactmaxm603125)/exactmaxm603125,abs(maxm60625 - exactmaxm60625)/exactmaxm60625,abs(maxm60125  - exactmaxm60125)/exactmaxm60125];

m6abs = [abs(maxm6015625 - exactmaxm6015625), abs(maxm603125 - exactmaxm603125),abs(maxm60625 - exactmaxm60625),abs(maxm60125  - exactmaxm60125)];

% compute norms of the difference |E-E_h|
L2m60125 =  norm(sampexcompabsE60_125 - sampcompabsE60_125);
L2m60625 =  norm(sampexcompabsE60_0625 - sampcompabsE60_0625);
L2m603125 =  norm(sampexcompabsE60_03125 - sampcompabsE60_03125);
L2m6015625 =  norm(sampexcompabsE60_015625 - sampcompabsE60_015625);

%compute L2 relative norms 
m6rel=[L2m6015625/exactmaxm6015625,L2m603125/exactmaxm603125,L2m60625/exactmaxm60625,L2m60125/exactmaxm60125];

m6=m6rel;

% Compute grad L_2 norm  for 3 meshes
%gradm6 =   [m6(1)/h(1), m6(2)/h(2),m6(3)/h(3)];

% Compute grad L_2 norm  for 4 meshes
gradm6 =   [m6rel(1)/h(1), m6rel(2)/h(2),m6rel(3)/h(3),m6rel(4)/h(4)];



% Compute L_2 norm   for 6 meshes
%m6= [h(1)*h(1)*maxm6015625, h(2)*h(2)*maxm603125,h(3)*h(3)*maxm60625,h(4)*h(4)*maxm60125, h(5)*h(5)*maxm6025, h(6)*h(6)*maxm605];


% to plot h*h

% for 3 meshes


%h2= [h(1)*h(1),h(2)*h(2),h(3)*h(3)];

%h1 = [h(1),h(2),h(3)];

% for 4 meshes

h2= [h(1)*h(1),h(2)*h(2),h(3)*h(3),h(4)*h(4)];
h1 = [h(1),h(2),h(3),h(4)];


% for 5 meshes

%h2= [h(1)*h(1),h(2)*h(2),h(3)*h(3),h(4)*h(4),h(5)*h(5)];

%h1 = [h(1),h(2),h(3),h(4),h(5)];

% for 6 meshes
%h2= [h(1)*h(1),h(2)*h(2),h(3)*h(3),h(4)*h(4),h(5)*h(5),h(6)*h(6)];

%h1 = [h(1),h(2),h(3),h(4),h(5),h(6)];


h1
fprintf(' L2norm = %f\n', m6)

%**************  rel. slope for L_2 norm

%  L2relslop56 = m6(1,6)/m6(1,5)
%  L2relslop45 = m6(1,5)/m6(1,4)
   L2relslop34 = m6(1,4)/m6(1,3);
  L2relslop23 = m6(1,3)/m6(1,2);
  L2relslop12 = m6(1,2)/m6(1,1);

fprintf(' e_4/e_3 = %f\n', L2relslop34)
fprintf(' e_3/e_2 = %f\n', L2relslop23)
fprintf(' e_2/e_1 = %f\n', L2relslop12)



%*********************************************************************
% For grad
  grad34 = gradm6(1,4)/gradm6(1,3);
  grad23 = gradm6(1,3)/gradm6(1,2);
  grad12 = gradm6(1,2)/gradm6(1,1);


fprintf(' grad L2 %f\n', gradm6)


fprintf(' grade_4/grade_3 = %f\n',  grad34)
fprintf(' grade_3/grade_2 = %f\n',  grad23)
fprintf(' grade_2/grade_1 = %f\n',   grad12)


%***********************************************************************
%loglog(h,m6,'m --o', 'Linewidth',2);


plot(h,m6rel,'b : s', 'Linewidth',2, "MarkerSize", 7, "MarkerFaceColor", "c");

hold on
plot(h,gradm6,'r : s', 'Linewidth',2, "MarkerSize", 7, "MarkerFaceColor", "c");

% plot mesh size h 

plot(h,h1,'g -- d', 'Linewidth',2, "MarkerSize", 7, "MarkerFaceColor", "c");

% plot mesh size h*h

plot(h,h2,'c : s', 'Linewidth',2, "MarkerSize", 7, "MarkerFaceColor", "c");

%semilogx(h, m6,'r -.o', 'Linewidth',2);


set(gca, 'XScale', 'log', 'YScale', 'log');

title('Test with m=6')

legend('max_T ||  |E-E_h|||_{L_2}/ ||  |E|||_{L_2}','max_T || grad |E-E_h|||_{L_2}/ || grad |E|||_{L_2}', 'h','h^2')

%legend('relative grad error','grad error')

xlabel("mesh size h", "Interpreter", "Latex")
ylabel("relative error", "Interpreter", "Latex")

font_size = 10;
set(gca, "FontSize", font_size)

set(gcf, "Units", "Inches", "Position", [0, 0, 7, 7], ...
       "PaperUnits", "Inches", "PaperSize", [7, 7])

 %saveas(gcf, sprintf("hybFEMm6.pdf"))




